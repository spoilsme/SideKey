#!/system/bin/sh
# 铃声模式循环切换：响铃 → 震动 → 静音 → 响铃
#
# v1.6.3 修两个致命问题：
#  1) 旧版 `cmd audio ... >>"$LOG"` 把 cmd 的输出句柄指到存储卡日志文件，
#     而 cmd 会把这个句柄递给 system_server 代写，跨域写 FUSE 直接
#     Failed transaction —— 命令根本没执行成功。现在一律先捕获到变量再写日志。
#  2) 旧版把 mode_ringer 的值映射写反了（正确是 0=静音 1=震动 2=响铃），
#     读出来的"当前模式"是错的，导致永远切不到期望的模式。
# 想直接指定：RINGER_MODE=normal|vibrate|silent
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
LOG="$DATA/ringer.log"
log() { echo "$(date '+%m-%d %H:%M:%S') $*" >>"$LOG" 2>/dev/null; }

if [ -f "$LOG" ]; then
    sz=$(wc -c <"$LOG" 2>/dev/null)
    case "$sz" in ''|*[!0-9]*) sz=0 ;; esac
    [ "$sz" -gt 65536 ] && : >"$LOG"
fi

# ---------- 读当前模式 ----------
# 优先 dumpsys audio（AudioService 自己报的，最权威，输出走管道不踩 fd 炸弹）
# 输出形如：Ringer mode: -mRingerMode=2 (NORMAL) 或 ringer mode= 2 (NORMAL)
get_mode() {
    o=$(dumpsys audio 2>/dev/null | grep -i 'ringer mode' | head -n 1)
    m=$(echo "$o" | grep -oE '[0-9]+' | head -n 1)
    case "$m" in
        0) echo SILENT;  return ;;
        1) echo VIBRATE; return ;;
        2) echo NORMAL;  return ;;
    esac
    # 退路 1：官方 cmd（ColorOS 上大多有；捕获式调用，不重定向到文件）
    o=$(cmd audio get-ringer-mode 2>/dev/null | tr -d ' \r' | tr 'a-z' 'A-Z')
    case "$o" in
        NORMAL|VIBRATE|SILENT) echo "$o"; return ;;
    esac
    # 退路 2：settings（0=静音 1=震动 2=响铃）
    v=$(settings get global mode_ringer 2>/dev/null | tr -cd '0-9')
    case "$v" in
        0) echo SILENT;  return ;;
        1) echo VIBRATE; return ;;
        2) echo NORMAL;  return ;;
    esac
    echo ""
}

cur=$(get_mode)
log "当前=$cur"

want="${RINGER_MODE:-}"
if [ -n "$want" ]; then
    want=$(echo "$want" | tr 'a-z' 'A-Z')
else
    case "$cur" in
        NORMAL)  want=VIBRATE ;;
        VIBRATE) want=SILENT ;;
        *)       want=NORMAL ;;
    esac
fi
log "目标=$want"

# ---------- 设为目标模式 ----------
ok=0
# 方式 1：AudioService 官方 shell 命令（输出先进变量，绝不直接进日志文件）
o=$(cmd audio set-ringer-mode "$want" 2>&1)
case "$o" in
    *ringer*|*Usage*|*Error*|*error*|*Exception*) log "cmd audio: $o" ;;
esac
[ "$(get_mode)" = "$want" ] && ok=1

# 方式 2：小写参数再试一次（个别 ROM 只认小写）
if [ "$ok" != "1" ]; then
    o=$(cmd audio set-ringer-mode "$(echo "$want" | tr 'A-Z' 'a-z')" 2>&1)
    [ "$(get_mode)" = "$want" ] && ok=1
fi

# 方式 3：写 settings（0=静音 1=震动 2=响铃；部分 ROM 会即时生效，有些要等 AudioService 刷新）
case "$want" in NORMAL) num=2 ;; VIBRATE) num=1 ;; SILENT) num=0 ;; esac
if [ "$ok" != "1" ]; then
    settings put global mode_ringer "$num" >/dev/null 2>&1
    settings put system oplus_mode_ringer "$num" >/dev/null 2>&1
    sleep 0.3
    [ "$(get_mode)" = "$want" ] && ok=1
fi

sleep 0.2
now=$(get_mode)
if [ "$now" = "$want" ]; then
    log "完成：$cur → $now"
else
    log "失败：$cur → $now（期望 $want，实际 $now）。ringer.log 留了每种方式的输出，发出来排查"
fi
exit 0

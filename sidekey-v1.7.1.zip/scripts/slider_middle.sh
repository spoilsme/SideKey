#!/system/bin/sh
# 三段式拨到中间（震动位）
cmd audio set-ringer-mode VIBRATE >/dev/null 2>&1
exit 0

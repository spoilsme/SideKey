#!/system/bin/sh
# 相机
am start -a android.media.action.STILL_IMAGE_CAMERA >/dev/null 2>&1
exit 0

#!/system/bin/sh
# 上一曲
input keyevent 88 >/dev/null 2>&1
exit 0

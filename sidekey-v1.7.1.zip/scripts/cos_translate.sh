#!/system/bin/sh
# 屏幕翻译（ColorOS 全局翻译）
am start-foreground-service -a oplus.intent.action.GLOBAL_TRANSLATION >/dev/null 2>&1
exit 0

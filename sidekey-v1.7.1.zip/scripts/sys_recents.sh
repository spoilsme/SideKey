#!/system/bin/sh
# 最近任务
input keyevent 187 >/dev/null 2>&1
exit 0

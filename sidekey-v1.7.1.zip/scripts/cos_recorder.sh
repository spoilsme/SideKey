#!/system/bin/sh
# 录音 开/关（ColorOS 录音机）
if dumpsys activity services com.coloros.soundrecorder 2>/dev/null | grep -q "soundrecorder"; then
    am force-stop com.coloros.soundrecorder >/dev/null 2>&1
else
    am start --user 0 -n com.coloros.soundrecorder/.TransparentActivity >/dev/null 2>&1
fi
exit 0

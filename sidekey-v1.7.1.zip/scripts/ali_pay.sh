#!/system/bin/sh
# 支付宝付款码
am start -a android.intent.action.VIEW -d "alipays://platformapi/startapp?appId=20000056" >/dev/null 2>&1
exit 0

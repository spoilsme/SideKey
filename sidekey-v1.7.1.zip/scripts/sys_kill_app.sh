#!/system/bin/sh
# 杀掉前台应用（识别当前焦点窗口的包名后 force-stop）
pkg=$(dumpsys window 2>/dev/null | grep -m1 mCurrentFocus | sed 's/.*u0 \([^}/ ]*\).*/\1/')
[ -n "$pkg" ] && am force-stop "$pkg"
exit 0

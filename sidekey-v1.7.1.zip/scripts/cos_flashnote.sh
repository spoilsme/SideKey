#!/system/bin/sh
# 一键闪记 · ColorOS 14 与新版本接口不一样，先试新的，报错再试旧的
out=$(am start-foreground-service \
      -n com.oplus.gleanerservice/.flashnotes.business.service.DataCollectService \
      -a oplus.gleanerservice.intent.action.COLLECT_DATA --ei triggerType 1 2>&1)
case "$out" in
    *rror*|*xception*|*Unable*)
        am start-foreground-service -p com.coloros.colordirectservice --ei triggerType 12 >/dev/null 2>&1
        ;;
esac
exit 0

#!/system/bin/sh
# 主页
input keyevent 3 >/dev/null 2>&1
exit 0

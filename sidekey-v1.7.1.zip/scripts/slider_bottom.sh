#!/system/bin/sh
# 三段式拨到最下（响铃位）
cmd audio set-ringer-mode NORMAL >/dev/null 2>&1
exit 0

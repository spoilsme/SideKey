#!/system/bin/sh
# 播放 / 暂停
input keyevent 85 >/dev/null 2>&1
exit 0

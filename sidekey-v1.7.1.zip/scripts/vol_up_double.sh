#!/system/bin/sh
# 双击音量上 → 下一曲
# 参数：$1=按键名 $2=手势 $3=连击次数 $4=三段式位置
input keyevent 87 >/dev/null 2>&1   # KEYCODE_MEDIA_NEXT

#!/system/bin/sh
# 双击音量下 → 上一曲
input keyevent 88 >/dev/null 2>&1   # KEYCODE_MEDIA_PREVIOUS

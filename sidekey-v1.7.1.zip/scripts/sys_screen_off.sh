#!/system/bin/sh
# 息屏
input keyevent 223 >/dev/null 2>&1
exit 0

#!/system/bin/sh
# 长截图（ColorOS 的截图服务）
service call color_screenshot 1 i32 1 i32 100 i32 1279544898 i32 1 s16 "screenshot_source" i32 0 s16 "systemQuickTileLongshot" >/dev/null 2>&1
exit 0

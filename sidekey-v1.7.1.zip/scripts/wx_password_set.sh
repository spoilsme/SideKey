#!/system/bin/sh
# 锁屏密码加密保存（v1.6.9 新增，WebUI「保存密码配置」调用）
#
# 用法：wx_password_set.sh <纯数字密码> <chain 0|1>
#       wx_password_set.sh --clear <chain 0|1>     （清除密码，保留/设置 chain）
#
# 安全设计：
#   · 密码永不以明文落盘。conf 里只写加密串 enc=xxx。
#   · 加密方式：对每一位数字做 mod-10 流加密（一次一密），
#     密钥每次保存时重新用 /dev/urandom 随机生成，长度 ≥ 密码位数。
#   · 密钥存 /data/adb/sidekey/.pkey（目录 700、文件 600，普通应用无法读取）。
#     密码本体在共享存储 /storage/.../sidekey/wx_password.conf，即使被
#     其他应用读到，没有 root 也拿不到密钥，还原不出密码。
#   · 模块不联网、不上传任何数据。
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
CONF="$DATA/wx_password.conf"
KEYDIR=/data/adb/sidekey
KEYFILE="$KEYDIR/.pkey"
LOG="$DATA/wx.log"
log() { echo "$(date '+%m-%d %H:%M:%S') 密码配置: $*" >>"$LOG" 2>/dev/null; }

DIG="$1"
CHAIN="${2:-0}"
case "$CHAIN" in 1) CHAIN=1 ;; *) CHAIN=0 ;; esac

if [ "$DIG" = "--clear" ] || [ -z "$DIG" ]; then
    mkdir -p "$DATA" 2>/dev/null
    printf '# 由 WebUI 生成\n#enc=\nchain=%s\n' "$CHAIN" >"$CONF" 2>/dev/null
    rm -f "$KEYFILE" 2>/dev/null
    log "已清除密码配置（chain=$CHAIN）"
    exit 0
fi

case "$DIG" in *[!0-9]*|"") echo "ERR: 密码必须是纯数字" >&2; exit 1 ;; esac

# ---------- 生成一次一密密钥（长度 = 密码位数） ----------
L=$(printf %s "$DIG" | wc -c | tr -d ' ')
mkdir -p "$KEYDIR" 2>/dev/null
chmod 700 "$KEYDIR" 2>/dev/null
KEY=$(od -An -N"$L" -tu1 /dev/urandom 2>/dev/null | awk '{for(i=1;i<=NF;i++) printf "%d", $i%10}')
# od 单次输出可能不足 L 位（按行截断），补齐
while [ "$(printf %s "$KEY" | wc -c | tr -d ' ')" -lt "$L" ]; do
    KEY="$KEY$(od -An -N8 -tu1 /dev/urandom 2>/dev/null | awk '{for(i=1;i<=NF;i++) printf "%d", $i%10}')"
done
printf %s "$KEY" >"$KEYFILE" 2>/dev/null
chmod 600 "$KEYFILE" 2>/dev/null

# ---------- mod-10 加密并写入 conf ----------
ENC=$(printf %s "$DIG" | awk -v k="$KEY" '{
    for (i = 1; i <= length($0); i++) {
        j = (i - 1) % length(k) + 1
        printf "%d", (substr($0, i, 1) + substr(k, j, 1)) % 10
    }
}')
if [ -z "$ENC" ]; then
    echo "ERR: 加密失败" >&2
    exit 1
fi
mkdir -p "$DATA" 2>/dev/null
printf '# 由 WebUI 生成（已加密存储；密钥在 %s，仅 root 可读；模块不联网不上传）\nenc=%s\nchain=%s\n' "$KEYFILE" "$ENC" "$CHAIN" >"$CONF" 2>/dev/null
log "密码已加密保存（$L 位，一次一密，chain=$CHAIN）"
echo "OK:$L"

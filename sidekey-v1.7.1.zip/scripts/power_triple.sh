#!/system/bin/sh
# 三击电源键 → 截图
# 逻辑统一挪到 cos_screenshot.sh（优先 ColorOS 原生截图服务），这里只做转发，
# 保证旧配置里写 power_triple.sh 的人升级后行为不变。
exec sh "$(dirname "$0")/cos_screenshot.sh" "$@"

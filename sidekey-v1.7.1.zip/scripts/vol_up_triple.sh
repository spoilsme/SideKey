#!/system/bin/sh
# 三击音量上 → 播放/暂停
input keyevent 85 >/dev/null 2>&1   # KEYCODE_MEDIA_PLAY_PAUSE

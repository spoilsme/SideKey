#!/system/bin/sh
# WiFi 开/关（默认切换）· 想固定：WIFI_MODE=on sys_wifi.sh
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
LOG="$DATA/wifi.log"
log() { echo "$(date '+%m-%d %H:%M:%S') $*" >>"$LOG" 2>/dev/null; }

state() {
    v=$(settings get global wifi_on 2>/dev/null | tr -d ' \r')
    case "$v" in
        1) echo on ;;
        0) echo off ;;
        *) dumpsys wifi 2>/dev/null | grep -m1 -oE 'Wi-Fi is (enabled|disabled)' | grep -q enabled && echo on || echo off ;;
    esac
}

mode="${WIFI_MODE:-}"
before=$(state)
[ -z "$mode" ] && { if [ "$before" = "on" ]; then mode=off; else mode=on; fi; }

if [ "$mode" = "on" ]; then
    svc wifi enable 2>/dev/null
    settings put global wifi_on 1 2>/dev/null
else
    svc wifi disable 2>/dev/null
    settings put global wifi_on 0 2>/dev/null
fi

# 等状态真的切换（WiFi 是异步的）
i=0
while [ $i -lt 20 ]; do
    sleep 0.15
    [ "$(state)" = "$mode" ] && break
    i=$((i + 1))
done
now=$(state)
log "$before → $now（目标 $mode）"
[ "$now" = "$mode" ] && exit 0
exit 1

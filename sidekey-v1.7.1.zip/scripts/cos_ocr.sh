#!/system/bin/sh
# 小布识屏（全屏 OCR，可复制屏幕上的文字）
am start-foreground-service -a oplus.intent.action.DIRECT_SIDEBAR_SERVICE \ >/dev/null 2>&1
    -e extra_entrance_function full_screen_ocr \
    -e triggered_app com.coloros.smartsidebar >/dev/null 2>&1
exit 0

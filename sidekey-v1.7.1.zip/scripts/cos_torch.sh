#!/system/bin/sh
# 手电筒 开/关（切换）· 最大亮度
#
# 【v1.7.1 —— 开关沿用官方手势服务，只加亮度】
# 开关部分完全照搬实测稳定的做法（一加 Ace 6T 上从未出错）：
#     读 settings secure flashlight_enabled 判断当前状态
#     开 = OPlus 手势服务 ACTION_OPEN  + flashlight_enabled=1 + temperature_o_camera_flash_status=on
#     关 = OPlus 手势服务 ACTION_CLOSE + flashlight_enabled=0 + temperature_o_camera_flash_status=off
# 全程不碰 switch_* 使能通道（那是灯的电源闸，由 HAL 独家掌管）。
#
# 最大亮度只在"已经点亮之后"追加一步：把 led:torch_* 的 brightness 写到 max_brightness。
# 实测结论（2026-10-30 真机）：
#   · 点亮前不动 sysfs，HAL 状态机始终干净；
#   · 只写 torch_*（不写 switch_*）时，随后 ACTION_CLOSE 依旧正常关灯、零 Invalid Opcode；
#   · 因此控制中心手电筒不会再失灵，也不再需要等 10 秒复位。
# 速度：第一次约 0.5 秒（服务点亮 + 轮询 + 加码），之后同样是 0.5 秒左右。
#
# 万一真出问题（例如刷机后固件换了行为）：设置页点【修复手电筒】，或
#   TORCH_REPAIR=1 cos_torch.sh      —— 解绑/重绑闪光灯驱动 + 重启相机 HAL，约 10 秒，不用重启手机。
#
# 其它：TORCH_MODE=on|off 固定方向；TORCH_MAX=1..500 自定义加码值；TORCH_NO_BOOST=1 只当普通开关用
# 日志：$SIDEKEY_DATA/torch.log
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
LOG="$DATA/torch.log"
SVC_OPEN="am startservice -n com.oplus.gesture/.flashlight.FlashLightService -a com.oplus.flashlight.ACTION_OPEN"
SVC_CLOSE="am startservice -n com.oplus.gesture/.flashlight.FlashLightService -a com.oplus.flashlight.ACTION_CLOSE"

log() { echo "$(date '+%m-%d %H:%M:%S') $*" >>"$LOG" 2>/dev/null; }

# 日志别无限长
if [ -f "$LOG" ]; then
    sz=$(wc -c <"$LOG" 2>/dev/null)
    case "$sz" in ''|*[!0-9]*) sz=0 ;; esac
    [ "$sz" -gt 65536 ] && : >"$LOG"
fi

num() {
    v=$(cat "$1" 2>/dev/null)
    case "$v" in ''|*[!0-9]*) echo 0 ;; *) echo "$v" ;; esac
}

# torch_* = 亮度档（真正写它）；switch_* = 电源闸（只读，绝不写）
NODES=""
for f in /sys/class/leds/*torch*/brightness; do
    [ -e "$f" ] && NODES="$NODES $f"
done
NODES=${NODES# }
GATES=""
for f in /sys/class/leds/*switch*/brightness; do
    [ -e "$f" ] && GATES="$GATES $f"
done
GATES=${GATES# }

if [ -z "$NODES" ] && [ -z "$GATES" ]; then
    log "没找到闪光灯节点；/sys/class/leds 下有: $(ls /sys/class/leds 2>/dev/null | tr '\n' ' ')"
    exit 1
fi

# 一次 cat 读完所有节点（比逐个 cat 快 3 倍：80ms → 25ms）
gate_sum() {
    s=0
    for v in $(cat $GATES 2>/dev/null); do
        case "$v" in ''|*[!0-9]*) continue ;; esac
        s=$((s + v))
    done
    echo "$s"
}

torch_sum() {
    s=0
    for v in $(cat $NODES 2>/dev/null); do
        case "$v" in ''|*[!0-9]*) continue ;; esac
        s=$((s + v))
    done
    echo "$s"
}

# ---------- 驱动复位（修复入口，不用重启手机） ----------
first=${NODES%% *}
[ -z "$first" ] && first=${GATES%% *}
devpath=$(readlink -f "${first%/brightness}/device" 2>/dev/null)
devn=${devpath##*/}
drvpath=$(readlink -f "${devpath}/driver" 2>/dev/null)
drvn=${drvpath##*/}
BUSDIR=/sys/bus/platform/drivers/$drvn

restart_hal() {
    for p in $(ps -A -o PID,NAME 2>/dev/null | grep -i 'camera.provider' | grep -v grep | awk '{print $1}'); do
        kill "$p" 2>/dev/null
    done
}

rebind_driver() {
    [ -n "$devn" ] && [ -n "$drvn" ] && [ -e "$BUSDIR/unbind" ] || { log "复位跳过：找不到驱动绑定（$devn / $drvn）"; return 1; }
    for f in $NODES $GATES; do echo 0 >"$f" 2>/dev/null; done
    echo "$devn" >"$BUSDIR/unbind" 2>/dev/null
    echo "$devn" >"$BUSDIR/bind" 2>/dev/null && log "  驱动已重绑（$drvn），闪光灯硬件已复位"
    restart_hal
    log "  相机 HAL 已重启（几秒后自动就绪）"
}

if [ "$TORCH_REPAIR" = "1" ] || [ "$1" = "repair" ]; then
    log "repair: 复位闪光灯驱动（修复控制中心手电筒失灵）"
    rebind_driver
    settings put secure flashlight_enabled 0 2>/dev/null
    settings put system temperature_o_camera_flash_status off 2>/dev/null
    log "repair: 完成，控制中心手电筒应已恢复（无需重启手机）"
    exit 0
fi

# ---------- 加码 / 复位亮度 ----------
MAXV="${TORCH_MAX:-500}"
case "$MAXV" in ''|*[!0-9]*) MAXV=500 ;; esac

# 每个通道的目标值算一次就缓存（$(DATA)/torch.max，格式：节点路径 目标值），
# 之后 boost 直接按缓存写，省掉每次开灯 4 次 max_brightness 读。
MAXC="$DATA/torch.max"
build_max_cache() {
    : >"$MAXC" 2>/dev/null
    for f in $NODES; do
        m=$(num "${f%/brightness}/max_brightness")
        [ "$m" -gt 0 ] 2>/dev/null || m=500
        t=$MAXV
        [ "$t" -gt "$m" ] && t=$m
        echo "$f $t" >>"$MAXC"
    done
}
[ -s "$MAXC" ] || build_max_cache
# 缓存里的节点数和当前不一致（换机型/换固件）就重建
[ "$(wc -l <"$MAXC" 2>/dev/null | tr -d ' ')" = "$(echo $NODES | wc -w | tr -d ' ')" ] || build_max_cache

target_sum() {
    s=0
    while read -r p v; do
        case "$v" in ''|*[!0-9]*) continue ;; esac
        s=$((s + v))
    done <"$MAXC"
    echo "$s"
}

boost() {
    [ "${TORCH_NO_BOOST:-0}" = "1" ] && return 0
    [ -s "$MAXC" ] || return 0
    while read -r p v; do
        [ -e "$p" ] || continue
        echo "$v" >"$p" 2>/dev/null
    done <"$MAXC"
}

# ---------- 决定开还是关（以硬件电源闸 switch_* 为准） ----------
mode="${TORCH_MODE:-}"
cur=$(gate_sum)
if [ -z "$mode" ]; then
    # 闸（switch_*）就是灯的真实开关：有电就是开着 → 这次该关
    if [ "$cur" -gt 0 ]; then mode=off; else mode=on; fi
fi
log "→ $mode（闸 $cur / 亮度 $(torch_sum)）"

wait_gate() {   # $1 = 期望 1/0，最多约 2.4 秒（官方服务点亮/熄灭本身要 1 秒上下）
    i=0
    while [ "$i" -lt 20 ]; do
        sleep 0.1
        g=$(gate_sum)
        if [ "$1" = "1" ] && [ "$g" -gt 0 ]; then return 0; fi
        if [ "$1" = "0" ] && [ "$g" -eq 0 ]; then return 0; fi
        i=$((i + 1))
    done
    return 1
}

if [ "$mode" = "on" ]; then
    # ① 官方服务点亮（和你的脚本一模一样）
    $SVC_OPEN >/dev/null 2>&1
    settings put secure flashlight_enabled 1 2>/dev/null
    settings put system temperature_o_camera_flash_status on 2>/dev/null
    if ! wait_gate 1; then
        log "  第一次没点亮，再发一次 ACTION_OPEN"
        $SVC_OPEN >/dev/null 2>&1
        wait_gate 1
    fi
    if [ "$(gate_sum)" -gt 0 ]; then
        # ② 灯已亮。HAL 会在点亮后 100ms 左右写自己的默认档，等它写完再拉满，
        #    然后校验一遍（被覆盖就再写一次），最多补三次。
        sleep 0.12
        want=$(target_sum)
        k=0
        while [ "$k" -lt 3 ]; do
            boost
            [ "$(torch_sum)" -ge "$want" ] && break
            sleep 0.1
            k=$((k + 1))
        done
        # 最后再确认一次：HAL 若在更晚的时候压回默认档，这里补最后一笔
        sleep 0.2
        [ "$(torch_sum)" -lt "$want" ] && boost
        # ③ 万一 HAL 在加码后又把灯掐了（上一轮会话正在销毁时的竞态），补开一次
        if [ "$(gate_sum)" -eq 0 ]; then
            log "  加码后灯被 HAL 掐掉，补开一次"
            $SVC_OPEN >/dev/null 2>&1
            settings put secure flashlight_enabled 1 2>/dev/null
            if wait_gate 1; then sleep 0.12; boost; fi
        fi
        log "on 完成（亮度合计 $(torch_sum)）"
    else
        # 点亮失败：把两个状态量改回"关"，否则系统会一直以为灯开着（图标亮、点不开）
        settings put secure flashlight_enabled 0 2>/dev/null
        settings put system temperature_o_camera_flash_status off 2>/dev/null
        log "on 失败：官方服务没点亮（闸 0）。已把状态改回关；可点【修复手电筒】"
    fi
    exit 0
fi

# ---------- 关灯 ----------
$SVC_CLOSE >/dev/null 2>&1
settings put secure flashlight_enabled 0 2>/dev/null
settings put system temperature_o_camera_flash_status off 2>/dev/null
if wait_gate 0; then
    log "off 完成（闸 0 / 亮度 $(torch_sum)）"
    exit 0
fi

# 兜底：HAL 没关掉。先把 torch 清零让灯立刻灭，再补一次 CLOSE
log "  官方服务没关掉（闸 $(gate_sum)），清零兜底"
for f in $NODES; do echo 0 >"$f" 2>/dev/null; done
$SVC_CLOSE >/dev/null 2>&1
if wait_gate 0; then
    log "off 完成（清零兜底，灯已灭）"
else
    log "  HAL 状态未恢复（闸 $(gate_sum)），后台复位驱动，几秒后控制中心自动恢复"
    ( rebind_driver ) >/dev/null 2>&1 &
fi
exit 0

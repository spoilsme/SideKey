#!/system/bin/sh
# 双击电源键 → 打开相机
# 说明：仅"额外叠加"，电源键原本的息屏/亮屏照旧生效
am start -a android.media.action.STILL_IMAGE_CAMERA >/dev/null 2>&1

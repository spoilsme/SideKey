#!/system/bin/sh
# 截图 · 优先走 ColorOS 原生截图服务（有系统动画、进相册、遵守隐私限制）
# 服务不存在时退回 screencap，保证任何 ROM 都能用。
if service list 2>/dev/null | grep -q "color_screenshot"; then
    service call color_screenshot 1 >/dev/null 2>&1
    exit 0
fi
DIR=/sdcard/Pictures/Screenshots
mkdir -p "$DIR" 2>/dev/null
F="$DIR/SK_$(date +%Y%m%d_%H%M%S).png"
screencap -p "$F"
am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file://$F" >/dev/null 2>&1
exit 0

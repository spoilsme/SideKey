#!/system/bin/sh
# 手电筒 开/关（系统亮度·原版方案）
#
# 走 OPlus 自家的手势手电筒服务（com.oplus.gesture/.flashlight.FlashLightService），
# 和控制中心、双击亮屏手势走的是同一条路，跟相机 HAL 完全兼容——
# 用这个方案，控制中心手电筒永远不会失灵。亮度是系统默认值（约一半功率）。
# 想要最大功率请用 cos_torch.sh（最大亮度版）。
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
LOG="$DATA/torch.log"
log() { echo "$(date '+%m-%d %H:%M:%S') [原版] $*" >>"$LOG" 2>/dev/null; }

state="$(settings get secure flashlight_enabled 2>/dev/null | tr -d '[:space:]')"
log "当前 flashlight_enabled=$state"

if [ "$state" = "1" ]; then
    am startservice -n com.oplus.gesture/.flashlight.FlashLightService -a com.oplus.flashlight.ACTION_CLOSE >/dev/null 2>&1
    settings put secure flashlight_enabled 0 >/dev/null 2>&1
    settings put system temperature_o_camera_flash_status off >/dev/null 2>&1
    log "已通过 OPlus 服务关灯"
else
    am startservice -n com.oplus.gesture/.flashlight.FlashLightService -a com.oplus.flashlight.ACTION_OPEN >/dev/null 2>&1
    settings put secure flashlight_enabled 1 >/dev/null 2>&1
    settings put system temperature_o_camera_flash_status on >/dev/null 2>&1
    log "已通过 OPlus 服务开灯（系统亮度）"
fi
exit 0

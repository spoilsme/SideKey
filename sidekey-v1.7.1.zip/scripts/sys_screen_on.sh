#!/system/bin/sh
# 亮屏
input keyevent 224 >/dev/null 2>&1
exit 0

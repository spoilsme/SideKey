#!/system/bin/sh
# 蓝牙 开/关（默认切换）· 一加 / OPPO 通用
#
# 想固定成只开或只关：BT_MODE=on cos_bt.sh / BT_MODE=off cos_bt.sh
# 诊断日志：$SIDEKEY_DATA/bt.log（每次都会写"改之前是什么、动了什么、改之后是什么"）
#
# 命令选择：svc bluetooth 是 root 下最稳的开关方式；
# cmd bluetooth_manager 在很多 ColorOS 固件上直接 Failed transaction，只留作兜底。
# 注意：cmd/am/input 的输出不能重定向到存储上的日志文件——它们会把输出句柄
# 通过 binder 递给 system_server 代写，跨域写存储文件会直接失败，所以统一 >/dev/null。
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
LOG="$DATA/bt.log"
log() { echo "$(date '+%m-%d %H:%M:%S') $*" >>"$LOG" 2>/dev/null; }

if [ -f "$LOG" ]; then
    sz=$(wc -c <"$LOG" 2>/dev/null)
    case "$sz" in ''|*[!0-9]*) sz=0 ;; esac
    [ "$sz" -gt 65536 ] && : >"$LOG"
fi

# 读当前状态：settings 全员可用，cmd 最准（可用才用）
state() {
    v=$(settings get global bluetooth_on 2>/dev/null | tr -d ' \r')
    case "$v" in 1) echo on; return ;; 0) echo off; return ;; esac
    o=$(cmd bluetooth_manager getState 2>/dev/null | tr -d ' \r')
    case "$o" in
        *STATE_ON*|*STATE_TURNING_ON*) echo on; return ;;
        *STATE_OFF*|*STATE_TURNING_OFF*) echo off; return ;;
    esac
    o=$(dumpsys bluetooth_manager 2>/dev/null | grep -m1 -E '^ *state' | tr -d ' \r')
    case "$o" in
        *ON*) echo on; return ;;
        *OFF*) echo off; return ;;
    esac
    echo ""
}

mode="${BT_MODE:-}"
before=$(state)
[ -z "$mode" ] && { if [ "$before" = "on" ]; then mode=off; else mode=on; fi; }
log "状态=$before 目标=$mode"

if [ "$mode" = "on" ]; then
    svc bluetooth enable >/dev/null 2>&1
    # svc 之后状态没变再试 cmd（个别固件 svc 管不到）
    sleep 1
    now=$(state)
    if [ "$now" != "on" ]; then
        cmd bluetooth_manager enable >/dev/null 2>&1
    fi
else
    svc bluetooth disable >/dev/null 2>&1
    sleep 1
    now=$(state)
    if [ "$now" != "off" ]; then
        cmd bluetooth_manager disable >/dev/null 2>&1
    fi
fi

# 蓝牙状态是异步的，等它真的变过来（最多 4 秒）
i=0
while [ $i -lt 20 ]; do
    sleep 0.2
    now=$(state)
    [ -n "$now" ] && [ "$now" = "$mode" ] && break
    i=$((i + 1))
done
now=$(state)

if [ "$now" = "$mode" ]; then
    log "完成：$before → $now"
else
    log "失败：$before → ${now:-未知}（期望 $mode）。svc 与 cmd 都没生效，看 bt.log 并把日志发给作者"
fi
exit 0

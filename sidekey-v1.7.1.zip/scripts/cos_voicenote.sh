#!/system/bin/sh
# 小布随口记（语音速记）
# 想改成「结束录音」就把 longPressEventType 改成 2
am start-foreground-service -p com.coloros.colordirectservice \ >/dev/null 2>&1
    --ei triggerType 1 --ei longPressEventType 1 >/dev/null 2>&1
exit 0

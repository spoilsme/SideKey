#!/system/bin/sh
# 微信付款码（亮屏版）：屏幕开着时直接拉起付款码界面
# 锁屏场景请用 wx_pay_lock.sh（会自动亮屏并上滑解锁）
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
LOG="$DATA/wx.log"
log() { echo "$(date '+%m-%d %H:%M:%S') 付款码: $*" >>"$LOG" 2>/dev/null; }

# 轻微短震，给个"按到了"的反馈
cmd vibrator_manager synced oneshot -a 40 200 >/dev/null 2>&1

# 熄屏时只负责点亮（不上滑，交给锁屏版）
awake=$(dumpsys power 2>/dev/null | grep -c 'mWakefulness=Awake')
if [ "$awake" = "0" ]; then
    input keyevent KEYCODE_WAKEUP >/dev/null 2>&1
    log "已点亮屏幕（亮屏版不上滑）"
fi

am start -n com.tencent.mm/.plugin.offline.ui.WalletOfflineCoinPurseUI >/dev/null 2>&1
log "已拉起付款码"
exit 0

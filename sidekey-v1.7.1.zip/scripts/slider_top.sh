#!/system/bin/sh
# 三段式拨到最上（静音位）
#   block_original = false 时：系统和这里都设静音，重复设置无副作用
#   block_original = true  时：这里就成了唯一的执行者，行为看起来和原生一样
# 想换成别的功能（手电筒/相机/刷新率…），直接改这一行。
cmd audio set-ringer-mode SILENT >/dev/null 2>&1
exit 0

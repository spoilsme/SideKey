#!/system/bin/sh
# NFC 开/关（切换）
case "$(dumpsys nfc 2>/dev/null | grep -m1 -o 'mState=[a-zA-Z]*')" in
    mState=on) svc nfc disable >/dev/null 2>&1 ;;
    *) svc nfc enable >/dev/null 2>&1 ;;
esac
exit 0

#!/system/bin/sh
# =====================================================================
#  block_mode = hook 时，每次三段式切换后都会被调用
#  参数：$1=slider  $2=block  $3=1  $4=位置(0=上 1=中 2=下)
#
#  思路：系统已经把 铃声/勿扰 改掉了，这里再改回你想要的稳定状态。
#
#  ⚠ 老实说：Android 没有稳定的 shell 接口直接设置"铃声模式"
#    （righnger mode 只在 AudioManager Java API 里）。
#    所以 hook 方式能做到的主要是"把勿扰状态改回去"。
#    想要彻底不让系统响应三段式，请优先用 block_mode = mount。
# =====================================================================

# 等系统先改完，避免抢在它前面
sleep 0.4

POS="$4"
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
echo "$(date '+%F %T') block hook, position=$POS" >> "$DATA/hook.log" 2>/dev/null

# 示例：无论滑块在哪，都保持"勿扰关闭"
# settings put global zen_mode 0

# 示例：如果你的固件把三段式写进了 global 的 three_Key_mode，可以改回来
# settings put global three_Key_mode 3

# 示例：想做更复杂的事情，可以在这里调用别的脚本
# sh "$DATA/scripts/my_restore.sh" "$POS"

exit 0

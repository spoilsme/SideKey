#!/system/bin/sh
# 下一曲
input keyevent 87 >/dev/null 2>&1
exit 0

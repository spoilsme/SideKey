#!/system/bin/sh
# 三击音量下 → 静音开关
input keyevent 164 >/dev/null 2>&1  # KEYCODE_VOLUME_MUTE

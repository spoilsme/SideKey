#!/system/bin/sh
# 音量 +
input keyevent 24 >/dev/null 2>&1
exit 0

#!/system/bin/sh
# 微信扫一扫
am start -n com.tencent.mm/.plugin.scanner.ui.BaseScanUI >/dev/null 2>&1
exit 0

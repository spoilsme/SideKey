#!/system/bin/sh
# 录屏 开/关（ColorOS 自带录屏器，正在录就停，否则打开录屏面板）
if dumpsys activity services com.oplus.screenrecorder 2>/dev/null | grep -q "RecorderService"; then
    am broadcast -a com.oplus.screenrecorder.ACTION_STOP_SCREEN_RECORDING -p com.oplus.screenrecorder >/dev/null 2>&1
else
    am start -n com.oplus.screenrecorder/.MainActivity >/dev/null 2>&1
fi
exit 0

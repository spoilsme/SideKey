#!/system/bin/sh
# 支付宝出行码（地铁 / 公交乘车码）
#
# 老的写死了一个 activity 类名，支付宝改版后这个类没了，所以点了没反应。
# 现在优先用 scheme 直达"出行"频道，再退回几个已知的类名。
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
LOG="$DATA/ali.log"
log() { echo "$(date '+%m-%d %H:%M:%S') 出行码: $*" >>"$LOG" 2>/dev/null; }

ok=""

# 1) scheme 直达出行（乘车码）
am start -a android.intent.action.VIEW -d "alipays://platformapi/startapp?appId=200011235" >/dev/null 2>&1 && ok=scheme

# 2) 乘车码专用 appId
if [ -z "$ok" ]; then
    am start -a android.intent.action.VIEW -d "alipays://platformapi/startapp?appId=20000067" >/dev/null 2>&1 && ok=scheme-ride
fi

# 3) 老类名兜底
if [ -z "$ok" ]; then
    am start -n com.eg.android.AlipayGphone/com.alipay.android.phone.wallet.aptrip.ui.ApTripActivity >/dev/null 2>&1 && ok=activity
fi

# 4) 实在不行就只打开支付宝首页
if [ -z "$ok" ]; then
    am start -n com.eg.android.AlipayGphone/.AlipayLogin >/dev/null 2>&1 && ok=home
fi

log "${ok:-全部失败}"
[ -n "$ok" ] && exit 0
exit 1

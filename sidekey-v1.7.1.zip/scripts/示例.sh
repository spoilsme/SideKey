#!/system/bin/sh
# 名称: 示例
#
# 这就是一个普通的 shell 脚本，写什么就执行什么。改完不用重启，下次按键直接生效。
#
# 能用的变量：
#   $1          按键名（volume_up / volume_down / power …）
#   $2          手势（single / double / triple / long …）
#   $3          连击次数
#   $SIDEKEY_DATA   数据目录，写自己的日志就往这里写
#
# 想让脚本在任何界面都能跑，跟手动在终端里敲命令一样，直接用 am / svc / settings / input 就行。
# 例：打开某个 App、发个通知、点一下屏幕……
#
# 下面这行只是往 demo.log 里记一笔，方便你确认"到底有没有被执行"：

echo "$(date '+%F %T') 触发 按键=$1 手势=$2 次数=$3" >> "$SIDEKEY_DATA/demo.log"

# 把这行换成你想干的事，例如：
#   am start -n com.tencent.mm/.ui.LauncherUI          # 打开微信
#   input keyevent KEYCODE_HOME                        # 回桌面
#   cmd notification post -S bigtext -t 侧键增强 "跑通了"

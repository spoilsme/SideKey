#!/system/bin/sh
# 自动输入微信/锁屏密码（v1.6.4 起支持「自动找键」，v1.6.9 起密码加密存储 + 键盘坐标缓存提速）
#
# 原理：密码键盘弹出后，系统会把每个数字键的位置报出来，
# 脚本自己解析出每个数字的中心点，按你设定的密码顺序逐个点。
#
# 提速（v1.6.9）：uiautomator 抓一次屏要 2~3 秒。首次校准成功后，把
# 数字键坐标缓存到 $DATA/wx_keypad.cache，之后直接按缓存坐标输入
# （免抓屏），输完用 dumpsys 轻量校验锁屏是否解开；没解开自动回退
# 精确模式（重新抓屏）并刷新缓存。想强制重新校准：WX_KEYPAD_REFRESH=1
#
# 配置文件 $SIDEKEY_DATA/wx_password.conf：
#   加密方式（推荐，WebUI 保存即为此格式）
#     enc=012345...        ← 加密后的密码；密钥在 /data/adb/sidekey/.pkey
#                             （仅 root 可读，每次保存重新随机生成 = 一次一密）
#   明文方式（老格式，仍兼容，建议到 WebUI 重新保存一次转为加密）
#     digits=123456
#   老办法（不推荐）坐标行，一行一个 x y
#
# 相关环境变量：
#   WX_PASSWORD_DELAY      每次点按间隔秒数（默认 0.12）
#   WX_PASSWORD_UNLOCK=0   关掉锁屏自动解锁
#   WX_KEYPAD_REFRESH=1    强制重新校准键盘坐标
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
CONF="$DATA/wx_password.conf"
CACHE="$DATA/wx_keypad.cache"
KEYFILE=/data/adb/sidekey/.pkey
LOG="$DATA/wx.log"
log() { echo "$(date '+%m-%d %H:%M:%S') 密码: $*" >>"$LOG" 2>/dev/null; }

DELAY="${WX_PASSWORD_DELAY:-0.12}"

# 【重要】绝不自动创建/覆盖配置文件！
# 以前"文件不存在就生成一份模板"，结果开机瞬间 /storage 还没挂好、文件读不到，
# 就当场写了一份空模板，把用户已加密保存的密码覆盖掉（v1.6.9 实测踩过）。
# 现在只读不写：没有就明确报错，交给 WebUI 去配。
if [ ! -f "$CONF" ]; then
    log "配置文件不存在：$CONF（未配置密码，或存储还没就绪）；请到 WebUI 配置"
    exit 1
fi
CONF_SZ=$(wc -c <"$CONF" 2>/dev/null)
case "$CONF_SZ" in ''|*[!0-9]*) CONF_SZ=0 ;; esac
if [ "$CONF_SZ" -lt 4 ]; then
    log "配置文件是空的：$CONF；请到 WebUI 重新保存密码"
    exit 1
fi

# ---------- 轻量锁屏状态（比 uiautomator 快得多） ----------
keyguard_up()   { dumpsys window policy 2>/dev/null | grep -q 'showing=true'; }
keyguard_down() { dumpsys window policy 2>/dev/null | grep -q 'showing=false'; }

# 读配置：优先 enc 加密格式，其次 digits 明文（老格式兼容）
DIGITS=""
ENC=$(grep -m1 '^enc=' "$CONF" 2>/dev/null | cut -d= -f2- | tr -d ' \r')
case "$ENC" in *[!0-9]*|"") ENC="" ;; esac
if [ -n "$ENC" ]; then
    KEY=$(cat "$KEYFILE" 2>/dev/null | tr -d ' \r\n')
    case "$KEY" in *[!0-9]*|"") KEY="" ;; esac
    if [ -z "$KEY" ]; then
        log "解密失败：密钥文件 $KEYFILE 读不到，请到 WebUI 重新保存一次密码"
        exit 1
    fi
    DIGITS=$(printf %s "$ENC" | awk -v k="$KEY" '{
        for (i = 1; i <= length($0); i++) {
            j = (i - 1) % length(k) + 1
            printf "%d", (substr($0, i, 1) - substr(k, j, 1) + 10) % 10
        }
    }')
    log "密码已从加密配置解密（一次一密，密钥仅 root 可读）"
fi
if [ -z "$DIGITS" ]; then
    DIGITS=$(grep -m1 '^digits=' "$CONF" 2>/dev/null | cut -d= -f2- | tr -d ' \r')
    case "$DIGITS" in
        *[!0-9]*|"") DIGITS="" ;;
        *) log "当前为明文 digits 格式（兼容读取），建议到 WebUI 重新保存一次转为加密存储" ;;
    esac
fi
POINTS=""
if [ -z "$DIGITS" ]; then
    POINTS=$(grep -v '^[[:space:]]*#' "$CONF" 2>/dev/null | grep -E '^[[:space:]]*[0-9]+[[:space:]]+[0-9]+' | head -n 12)
fi

if [ -z "$DIGITS" ] && [ -z "$POINTS" ]; then
    log "conf 里没有密码（enc/digits 都为空）也没有坐标，不动作：$CONF"
    exit 1
fi

# ---------- 屏幕尺寸 ----------
size=$(wm size 2>/dev/null | sed -n 's/.*: \([0-9][0-9]*\)x\([0-9][0-9]*\).*/\1 \2/p' | tail -n 1)
W=$(echo "$size" | cut -d' ' -f1); H=$(echo "$size" | cut -d' ' -f2)
case "$W" in ''|*[!0-9]*) W=1080 ;; esac
case "$H" in ''|*[!0-9]*) H=2400 ;; esac
[ "$W" -lt "$H" ] || { T=$W; W=$H; H=$T; }
MAX_OFF=$((W / 60)); [ "$MAX_OFF" -lt 1 ] && MAX_OFF=1

rand_off() {
    raw=$(od -An -N2 -tu2 /dev/urandom 2>/dev/null | tr -d ' \n')
    case "$raw" in ''|*[!0-9]*) raw=$(date +%s) ;; esac
    echo $(( raw % (2 * $1 + 1) - $1 ))
}

# ---------- 抓取界面（精确模式用） ----------
KPFILE=/data/local/tmp/.sk_keypad.xml
KP=""

# 抓一次 uiautomator dump，结果存 KP。返回 0 = 抓到了密码键盘。
grab_keypad() {
    uiautomator dump "$KPFILE" >/dev/null 2>&1
    KP=$(cat "$KPFILE" 2>/dev/null)
    rm -f "$KPFILE" 2>/dev/null
    if [ -n "$KP" ] && echo "$KP" | grep -q 'content-desc="0"'; then return 0; fi
    if [ -n "$KP" ] && echo "$KP" | grep -q '密码栏'; then return 0; fi
    KP=""
    return 1
}

# ColorOS 两步解锁：亮屏 → 菜单键抬起锁屏 → 最底部手势区上滑一次
unlock_swipe() {
    awake=$(dumpsys power 2>/dev/null | grep -c 'mWakefulness=Awake')
    if [ "$awake" = "0" ]; then
        input keyevent KEYCODE_WAKEUP >/dev/null 2>&1
        i=0
        while [ $i -lt 20 ]; do
            sleep 0.1
            awake=$(dumpsys power 2>/dev/null | grep -c 'mWakefulness=Awake')
            [ "$awake" != "0" ] && break
            i=$((i + 1))
        done
    fi
    sleep 0.4
    x=$((W / 2)); sy=$((H * 98 / 100)); ey=$((H * 50 / 100))
    input keyevent 82 >/dev/null 2>&1
    sleep 0.4
    input swipe "$x" "$sy" "$x" "$ey" 600 >/dev/null 2>&1
    log "锁屏中：已亮屏并从底部上滑（$x,$sy → $x,$ey）"
    sleep 0.3
}

# ---------- 键盘坐标缓存 ----------
cache_valid() { [ -s "$CACHE" ] && [ "${WX_KEYPAD_REFRESH:-0}" != "1" ]; }

# 从缓存坐标点一位数字
cache_tap_digit() {   # $1 = 数字
    line=$(grep -m1 "^$1 " "$CACHE" 2>/dev/null)
    case "$line" in ''|*[!0-9\ ]*) return 1 ;; esac
    cx=$(echo "$line" | awk '{print $2}')
    cy=$(echo "$line" | awk '{print $3}')
    case "$cx" in ''|*[!0-9]*) return 1 ;; esac
    case "$cy" in ''|*[!0-9]*) return 1 ;; esac
    dx=$(rand_off "$MAX_OFF"); dy=$(rand_off "$MAX_OFF")
    input tap "$((cx + dx))" "$((cy + dy))" >/dev/null 2>&1
    return 0
}

# 从抓到的界面里把 0-9 每个键的中心点写进缓存
save_cache() {
    [ -n "$KP" ] || return 1
    {
        d=0
        while [ "$d" -le 9 ]; do
            b=$(echo "$KP" | grep -o "<node[^>]*content-desc=\"$d\"[^>]*>" \
                | grep -o 'bounds="\[[0-9]*,[0-9]*\]\[[0-9]*,[0-9]*\]"' | head -n 1)
            if [ -n "$b" ]; then
                echo "$b" | awk -v d="$d" -F'[^0-9]+' \
                    '{printf "%s %d %d\n", d, int(($2+$4)/2), int(($3+$5)/2)}'
            fi
            d=$((d + 1))
        done
    } >"$CACHE" 2>/dev/null
}

# ---------- 精确模式入口：确保抓到密码键盘 ----------
ensure_keypad() {
    if grab_keypad; then return 0; fi
    if [ "${WX_PASSWORD_UNLOCK:-1}" = "1" ]; then
        unlock_swipe
        grab_keypad || { sleep 0.5; grab_keypad; } || { sleep 0.5; grab_keypad; }
    else
        grab_keypad || { sleep 0.5; grab_keypad; } || { sleep 0.5; grab_keypad; }
    fi
    [ -n "$KP" ]
}

# ---------- 缓存快路：免抓屏直接输 ----------
cache_enter() {
    if [ "${WX_PASSWORD_UNLOCK:-1}" = "1" ] && [ "${WX_UNLOCK_DONE:-0}" != "1" ]; then
        keyguard_up || return 1      # 不在锁屏上，缓存乱点有风险，走精确模式
        unlock_swipe                 # 展开 bouncer（WX_UNLOCK_DONE=1 表示调用方已做过）
    fi
    len=$(echo -n "$DIGITS" | wc -c | tr -d ' ')
    i=1
    while [ "$i" -le "$len" ]; do
        d=$(echo "$DIGITS" | cut -c "$i")
        if ! cache_tap_digit "$d"; then
            log "缓存里没有数字 $d 的坐标，转精确模式"
            return 1
        fi
        sleep 0.08
        i=$((i + 1))
    done
    sleep 0.6
    if keyguard_down; then
        log "完成：缓存快路输入 $len 位，锁屏已解开"
        return 0
    fi
    log "缓存路径输完后锁屏未解开（键盘布局可能变了），转精确模式重新校准"
    return 1
}

tap_digit() {   # $1 = 数字 -> 找到并点下返回 0，找不到返回 1
    b=$(echo "$KP" | grep -o "<node[^>]*content-desc=\"$1\"[^>]*>" \
        | grep -o 'bounds="\[[0-9]*,[0-9]*\]\[[0-9]*,[0-9]*\]"' | head -n 1)
    [ -z "$b" ] && return 1
    # bounds="[left,top][right,bottom]" -> 键中心点
    # 注意：这里必须用自己算出的中心点。v1.6.8 之前误用了外面上滑坐标的 $y1
    #（屏幕 98% 高度，或未走解锁分支时为空），导致纵坐标全错、密码点不进去。
    xy=$(echo "$b" | awk -F'[^0-9]+' '{print int(($2+$4)/2), int(($3+$5)/2)}')
    kx=$(echo "$xy" | cut -d' ' -f1)
    ky=$(echo "$xy" | cut -d' ' -f2)
    case "$kx" in ''|*[!0-9]*) return 1 ;; esac
    case "$ky" in ''|*[!0-9]*) return 1 ;; esac
    dx=$(rand_off "$MAX_OFF"); dy=$(rand_off "$MAX_OFF")
    input tap "$((kx + dx))" "$((ky + dy))" >/dev/null 2>&1
    return 0
}

n=0
if [ -n "$DIGITS" ]; then
    if cache_valid && cache_enter; then
        exit 0
    fi
    # ---------- 精确模式（抓屏找键，结果写缓存供下次快路使用） ----------
    ensure_keypad
    if [ -z "$KP" ]; then
        log "自动找键失败：uiautomator dump 没抓到密码键盘"
        exit 1
    fi
    save_cache && log "键盘坐标已缓存（$CACHE），下次免抓屏更快"
    len=$(echo -n "$DIGITS" | wc -c | tr -d ' ')
    log "自动找键：按密码顺序输入（长度 $len）"
    i=1
    while [ "$i" -le "$len" ]; do
        d=$(echo "$DIGITS" | cut -c "$i")
        if tap_digit "$d"; then
            n=$((n + 1))
            log "第 $n 位（$d）已点下"
        else
            log "第 $i 位（$d）在键盘上没找到，中止"
            exit 1
        fi
        sleep "$DELAY"
        i=$((i + 1))
    done
    log "完成：共点下 $n 位"
    exit 0
fi

# ---------- 老的坐标点模式 ----------
echo "$POINTS" | while read -r x y; do
    [ -z "$x" ] && continue
    n=$((n + 1))
    dx=$(rand_off "$MAX_OFF"); dy=$(rand_off "$MAX_OFF")
    tx=$((x + dx)); [ "$tx" -lt 0 ] && tx=0
    ty=$((y + dy)); [ "$ty" -lt 0 ] && ty=0
    input tap "$tx" "$ty" >/dev/null 2>&1
    log "第 $n 点 → ($tx,$ty)"
    sleep "$DELAY"
done
exit 0

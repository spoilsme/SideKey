#!/system/bin/sh
# 语音助手
am start -a android.intent.action.VOICE_COMMAND >/dev/null 2>&1
exit 0

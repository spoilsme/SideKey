#!/system/bin/sh
# 便签速记（小窗悬浮便签）
am start -a action.nearme.note.quicknote --windowingMode 100 >/dev/null 2>&1
exit 0

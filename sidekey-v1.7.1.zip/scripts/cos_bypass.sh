#!/system/bin/sh
# 旁路充电 开/关（ColorOS 的「只供电不充电」，打游戏挂机用）
cur=$(settings get system bypass_charge_state 2>/dev/null | tr -cd '0-9')
[ "$cur" = "1" ] && settings put system bypass_charge_state 0 >/dev/null 2>&1 || settings put system bypass_charge_state 1 >/dev/null 2>&1
exit 0

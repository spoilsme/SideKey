#!/system/bin/sh
# 支付宝扫一扫
am start -a android.intent.action.VIEW -d "alipays://platformapi/startapp?appId=10000007" >/dev/null 2>&1
exit 0

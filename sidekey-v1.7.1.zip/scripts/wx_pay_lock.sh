#!/system/bin/sh
# 微信付款码（锁屏版）：熄屏/锁屏时也能用
#
# 流程：先拉起付款码界面（冷启动排队）→ 亮屏并等屏幕真正亮起来 →
# 菜单键抬起锁屏 → 从最底部手势区上滑一次，弹出密码/人脸界面。
# 解锁成功后付款码就在前面了。
#
# ColorOS 实测（v1.6.4）：
#  · 从屏幕中部上滑会被锁屏吞掉，必须从最底部（约 98% 高度处）起滑；
#  · 直接上滑无效，要先按一次菜单键（keyevent 82）抬起锁屏；
#  · 密码键盘弹出后不能再滑第二次（会退回锁屏）。
# 上滑坐标按本机分辨率自动算。关掉自动解锁：WX_PAY_UNLOCK=0
DATA="${SIDEKEY_DATA:-/storage/emulated/0/Android/sidekey}"
LOG="$DATA/wx.log"
log() { echo "$(date '+%m-%d %H:%M:%S') 付款码锁屏: $*" >>"$LOG" 2>/dev/null; }

cmd vibrator_manager synced oneshot -a 40 200 >/dev/null 2>&1

# 屏幕尺寸（上滑坐标按比例算，横竖分辨率取大者为宽）
size=$(wm size 2>/dev/null | sed -n 's/.*: \([0-9][0-9]*\)x\([0-9][0-9]*\).*/\1 \2/p' | tail -n 1)
W=$(echo "$size" | cut -d' ' -f1); H=$(echo "$size" | cut -d' ' -f2)
case "$W" in ''|*[!0-9]*) W=1080 ;; esac
case "$H" in ''|*[!0-9]*) H=2400 ;; esac
[ "$W" -lt "$H" ] || { T=$W; W=$H; H=$T; }

am start -n com.tencent.mm/.plugin.offline.ui.WalletOfflineCoinPurseUI >/dev/null 2>&1
log "已拉起付款码（${W}x${H}）"

[ "${WX_PAY_UNLOCK:-1}" = "0" ] && exit 0

# ---------- 锁屏检测（猜不出来就按锁屏处理，这是锁屏版） ----------
locked=1
d=$(dumpsys window policy 2>/dev/null)
case "$d" in
    *showing=false*) locked=0 ;;
esac

if [ "$locked" = "1" ]; then
    # 唤醒
    awake=$(dumpsys power 2>/dev/null | grep -c 'mWakefulness=Awake')
    if [ "$awake" = "0" ]; then
        input keyevent KEYCODE_WAKEUP >/dev/null 2>&1
        i=0
        while [ $i -lt 20 ]; do          # 最多等 2 秒，屏幕真亮了才继续
            sleep 0.1
            awake=$(dumpsys power 2>/dev/null | grep -c 'mWakefulness=Awake')
            [ "$awake" != "0" ] && break
            i=$((i + 1))
        done
        log "已唤醒屏幕（等待 $((i + 4))x0.1s）"
    fi
    sleep 0.4                            # 亮屏动画 + 事件分发要时间（v1.6.9 由 0.6 压缩）

    # ColorOS 两步解锁：菜单键抬起锁屏 → 最底部手势区上滑一次
    x=$((W / 2))
    y1=$((H * 98 / 100))
    y2=$((H * 50 / 100))
    input keyevent 82 >/dev/null 2>&1
    sleep 0.4                            # v1.6.9 由 0.6 压缩
    input swipe "$x" "$y1" "$x" "$y2" 600 >/dev/null 2>&1
    sleep 0.3                            # v1.6.9 由 0.5 压缩
    log "锁屏中：已按菜单键并从底部上滑（$x,$y1 → $x,$y2）"

    # 联动自动输密码：wx_password.conf 里写了 chain=1 且配了 digits 时，
    # 解锁到密码键盘后自动把密码输完（一键直达付款码）。
    # WX_UNLOCK_DONE=1：告诉密码脚本上滑已做过，不要重复（重复上滑会把
    # 已弹出的密码键盘收回锁屏）。
    if grep -q '^chain=1' "$DATA/wx_password.conf" 2>/dev/null; then
        log "chain=1：继续调用 wx_password.sh 自动输密码"
        WX_UNLOCK_DONE=1 sh "$(dirname "$0")/wx_password.sh"
    fi
else
    log "未锁屏，跳过解锁"
fi
exit 0

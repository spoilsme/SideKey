#!/system/bin/sh
# 免打扰 开/关（切换）
if [ "$(settings get global zen_mode 2>/dev/null)" = "0" ]; then
    cmd notification set_dnd on >/dev/null 2>&1 || settings put global zen_mode 1
else
    cmd notification set_dnd off >/dev/null 2>&1 || settings put global zen_mode 0
fi
exit 0

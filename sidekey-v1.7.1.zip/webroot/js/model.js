/* model.js - 配置 <-> 表单模型
 *
 * 职责：把 config.conf 解析成扁平对象给 UI 用，再把 UI 的改动写回去。
 * 依赖 iniconf.js（同作用域里的全局 IniConf）。
 * 该文件同时能在 node 里加载（tests/test_model.js），所以不要碰 DOM。
 */
var SideModel = (function () {
    'use strict';

    var GESTURES = [
        { key: 'single', label: '单击', field: 'single' },
        { key: 'double', label: '双击', field: 'double' },
        { key: 'triple', label: '三击', field: 'triple' },
        { key: 'four', label: '四击', field: 'four' },
        { key: 'five', label: '五击', field: 'five' },
        { key: 'long', label: '长按', field: 'long' }
    ];

    // code 是 Linux 键码，「监听添加按键」时用它把按到的键映射回名称
    var KEY_NAMES = [
        { name: 'volume_up', label: '音量上', code: 115 },
        { name: 'volume_down', label: '音量下', code: 114 },
        { name: 'power', label: '电源键', code: 116 },
        { name: 'camera', label: '相机键', code: 212 },
        { name: 'focus', label: '对焦键', code: 211 },
        { name: 'menu', label: '菜单键', code: 139 },
        { name: 'back', label: '返回键', code: 158 },
        { name: 'home', label: 'Home 键', code: 172 },
        { name: 'mute', label: '静音键', code: 113 },
        { name: 'play', label: '播放/暂停', code: 164 },
        { name: 'next', label: '下一曲', code: 163 },
        { name: 'prev', label: '上一曲', code: 165 },
        { name: 'headset', label: '耳机线控', code: 226 },
        { name: 'assist', label: '语音助手', code: 583 },
        { name: 'voice', label: '语音命令', code: 582 },
        { name: 'f13', label: 'F13（自定义键）', code: 183 },
        { name: 'f14', label: 'F14（自定义键）', code: 184 },
        { name: 'f15', label: 'F15（自定义键）', code: 185 }
    ];

    function intOr(v, d) {
        var n = parseInt(v, 10);
        return isNaN(n) ? d : n;
    }
    function boolOr(v, d) {
        if (v == null) return d;
        var t = String(v).trim().toLowerCase();
        if (t === 'true' || t === '1' || t === 'yes' || t === 'on') return true;
        if (t === 'false' || t === '0' || t === 'no' || t === 'off') return false;
        return d;
    }
    function replayToMask(v) {
        if (v == null) return 1;
        var t = String(v).trim().toLowerCase();
        if (t === 'none' || t === '-') return 0;
        if (t === 'all') return 59;   // bit0,1,2,4,5 = 单/双/三/四/五击
        var mask = 0;
        t.split(',').forEach(function (p) {
            p = p.trim();
            if (p === 'single' || p === '1') mask |= 1;
            else if (p === 'double' || p === '2') mask |= 2;
            else if (p === 'triple' || p === '3') mask |= 4;
            else if (p === 'four' || p === '4') mask |= 16;
            else if (p === 'five' || p === '5') mask |= 32;
        });
        return mask;
    }
    function maskToReplay(mask) {
        var out = [];
        if (mask & 1) out.push('single');
        if (mask & 2) out.push('double');
        if (mask & 4) out.push('triple');
        if (mask & 16) out.push('four');
        if (mask & 32) out.push('five');
        return out.length ? out.join(',') : 'none';
    }
    function labelOf(name) {
        for (var i = 0; i < KEY_NAMES.length; i++) if (KEY_NAMES[i].name === name) return KEY_NAMES[i].label;
        return name;
    }

    function load(text) {
        var conf = IniConf.parse(text);
        var g = function (k) { return IniConf.get(conf, 'general', '', k); };
        var s = function (k) { return IniConf.get(conf, 'slider', '', k); };

        var model = {
            general: {
                tap_window_ms: intOr(g('tap_window_ms'), 220),
                long_press_ms: intOr(g('long_press_ms'), 500),
                max_taps: intOr(g('max_taps'), 5),
                log_level: intOr(g('log_level'), 2),
                log_enabled: boolOr(g('log_enabled'), true),
                log_script: boolOr(g('log_script'), true),
                log_daemon_out: boolOr(g('log_daemon_out'), true),
                log_keep_min: intOr(g('log_keep_min'), 240),
                script_dir: g('script_dir') || '/storage/emulated/0/Android/sidekey/scripts',
                log_file: g('log_file') || '/storage/emulated/0/Android/sidekey/sidekeyd.log',
                volume_swap: (function (v) {
                    if (v == null) return 'auto';
                    v = String(v).trim().toLowerCase();
                    if (v === 'true' || v === 'on' || v === 'force' || v === '1') return 'on';
                    if (v === 'false' || v === 'off' || v === '0') return 'off';
                    return 'auto';
                })(g('volume_swap')),
                keep_screenshot: boolOr(g('keep_screenshot'), false)
            },
            keys: IniConf.blocks(conf, 'key').map(function (b) {
                var v = function (k) { return IniConf.get(conf, 'key', b.arg, k); };
                var tw = v('tap_window_ms'), lp = v('long_press_ms'), mt = v('max_taps');
                return {
                    name: b.arg,
                    label: labelOf(b.arg),
                    single: v('single') || v('tap') || 'none',
                    double: v('double') || v('double_tap') || 'none',
                    triple: v('triple') || v('triple_tap') || 'none',
                    four: v('four') || v('quadruple') || 'none',
                    five: v('five') || v('quintuple') || 'none',
                    long: v('long') || v('long_press') || 'none',
                    // gate_multi：多击拦截。老配置里的 suppress_original 当别名读
                    gate_multi: boolOr(v('gate_multi') != null ? v('gate_multi') : v('suppress_original'), true),
                    intercept: boolOr(v('intercept'), false),
                    hold_forward: boolOr(v('hold_forward'), false),
                    invert: boolOr(v('invert'), false),
                    tap_window_ms: tw == null ? '' : intOr(tw, ''),
                    long_press_ms: lp == null ? '' : intOr(lp, ''),
                    max_taps: mt == null ? '' : intOr(mt, '')
                };
            }),
            chords: IniConf.blocks(conf, 'chord').map(function (b) {
                var v = function (k) { return IniConf.get(conf, 'chord', b.arg, k); };
                return {
                    name: b.arg,
                    keys: String(v('keys') || '').split(',').map(function (x) { return String(x).trim(); }).filter(Boolean),
                    action: v('action') || v('script') || 'none',
                    window_ms: intOr(v('window_ms'), 250),
                    ordered: boolOr(v('ordered'), false),
                    block: boolOr(v('block'), false)
                };
            }),
            devices: IniConf.blocks(conf, 'device').map(function (b) {
                return {
                    name: b.arg,
                    grab: IniConf.get(conf, 'device', b.arg, 'grab') || 'auto',
                    forward: boolOr(IniConf.get(conf, 'device', b.arg, 'forward'), true)
                };
            }),
            slider: {
                backend: s('backend') || 'auto',
                proc_path: s('proc_path') || '/proc/tristatekey/tri_state',
                poll_ms: intOr(s('poll_ms'), 200),
                position_values: s('position_values') || '1,2,3',
                evdev_keys: s('evdev_keys') || '603,602,601',
                top: s('top') || s('action_top') || 'none',
                middle: s('middle') || s('mid') || s('action_middle') || 'none',
                bottom: s('bottom') || s('action_bottom') || 'none',
                block_original: boolOr(s('block_original'), false),
                block_mode: s('block_mode') || 'auto',
                block_paths: s('block_paths') || '',
                block_hook: s('block_hook') || 'block_restore.sh',
                uevent_match: s('uevent_match') || '',
                uevent_map: s('uevent_map') || ''
            }
        };
        return model;
    }

    // 空 -> 删掉这一行（让内置默认生效）；与默认值相同且文件里本来没写 -> 不新增
    // 这样"只改了一个开关"不会把整个文件重写一遍。
    function putField(conf, section, arg, key, value, defVal, force) {
        var exists = IniConf.get(conf, section, arg, key) !== null;
        var v = (value === null || value === undefined) ? '' : String(value).trim();
        if (v === '') {
            if (exists) IniConf.set(conf, section, arg, key, null);
            return;
        }
        if (!exists && !force && defVal !== undefined && v === String(defVal)) return;
        IniConf.set(conf, section, arg, key, v);
    }

    function b2s(v) { return v ? 'true' : 'false'; }

    function apply(conf, m) {
        // 配置文件被清空/刚建时，先保证两个必填段存在
        if (!IniConf.block(conf, 'general', '')) IniConf.addBlock(conf, 'general', '');
        if (!IniConf.block(conf, 'slider', '')) IniConf.addBlock(conf, 'slider', '');

        var g = m.general;
        putField(conf, 'general', '', 'tap_window_ms', g.tap_window_ms, 220);
        putField(conf, 'general', '', 'long_press_ms', g.long_press_ms, 500);
        putField(conf, 'general', '', 'max_taps', g.max_taps, 5);
        putField(conf, 'general', '', 'log_level', g.log_level, 2);
        // 三个日志开关强制落盘（force=true）：老配置升级后也能看见这几行，方便手改
        putField(conf, 'general', '', 'log_enabled', b2s(g.log_enabled), 'true', true);
        putField(conf, 'general', '', 'log_script', b2s(g.log_script), 'true', true);
        putField(conf, 'general', '', 'log_daemon_out', b2s(g.log_daemon_out), 'true', true);
        putField(conf, 'general', '', 'log_keep_min', g.log_keep_min, 240);
        putField(conf, 'general', '', 'script_dir', g.script_dir, '/storage/emulated/0/Android/sidekey/scripts');
        putField(conf, 'general', '', 'log_file', g.log_file, '/storage/emulated/0/Android/sidekey/sidekeyd.log');
        putField(conf, 'general', '', 'volume_swap', g.volume_swap, 'auto');
        putField(conf, 'general', '', 'keep_screenshot', b2s(g.keep_screenshot), 'false');

        // 组合键段
        var chordKeep = {};
        (m.chords || []).forEach(function (c) {
            if (!c.name || !c.keys || c.keys.length < 2) return;
            chordKeep[c.name] = true;
            var fresh = IniConf.block(conf, 'chord', c.name) === null;
            putField(conf, 'chord', c.name, 'keys', c.keys.join(','), '', fresh);
            putField(conf, 'chord', c.name, 'action', c.action || 'none', 'none', fresh);
            putField(conf, 'chord', c.name, 'window_ms', c.window_ms, 250, fresh);
            putField(conf, 'chord', c.name, 'ordered', b2s(c.ordered), 'false', fresh);
            putField(conf, 'chord', c.name, 'block', b2s(c.block), 'false', fresh);
        });
        IniConf.blocks(conf, 'chord').forEach(function (b) {
            if (!chordKeep[b.arg]) IniConf.removeBlock(conf, 'chord', b.arg);
        });

        // 设备段：先写现有/新增，再删掉模型里没有的
        var devKeep = {};
        m.devices.forEach(function (d) {
            if (!d.name) return;
            devKeep[d.name] = true;
            var fresh = IniConf.block(conf, 'device', d.name) === null;
            putField(conf, 'device', d.name, 'grab', d.grab, 'auto', fresh);
            putField(conf, 'device', d.name, 'forward', b2s(d.forward), 'true', fresh);
        });
        IniConf.blocks(conf, 'device').forEach(function (b) {
            if (!devKeep[b.arg]) IniConf.removeBlock(conf, 'device', b.arg);
        });

        // 按键段
        var keyKeep = {};
        m.keys.forEach(function (k) {
            if (!k.name) return;
            keyKeep[k.name] = true;
            var fresh = IniConf.block(conf, 'key', k.name) === null;
            putField(conf, 'key', k.name, 'single', k.single || 'none', 'none', fresh);
            putField(conf, 'key', k.name, 'double', k.double || 'none', 'none', fresh);
            putField(conf, 'key', k.name, 'triple', k.triple || 'none', 'none', fresh);
            putField(conf, 'key', k.name, 'four', k.four || 'none', 'none', fresh);
            putField(conf, 'key', k.name, 'five', k.five || 'none', 'none', fresh);
            putField(conf, 'key', k.name, 'long', k.long || 'none', 'none', fresh);
            putField(conf, 'key', k.name, 'gate_multi', b2s(k.gate_multi), 'true', fresh);
            putField(conf, 'key', k.name, 'intercept', b2s(k.intercept), 'false', fresh);
            putField(conf, 'key', k.name, 'hold_forward', b2s(k.hold_forward), 'false', fresh);
            putField(conf, 'key', k.name, 'invert', b2s(k.invert), 'false', fresh);
            // 老字段直接删掉，避免和 gate_multi 打架
            putField(conf, 'key', k.name, 'suppress_original', '');
            putField(conf, 'key', k.name, 'replay', '');
            // 可选覆盖项：留空就删掉，回到全局默认
            putField(conf, 'key', k.name, 'tap_window_ms', isBlank(k.tap_window_ms) ? '' : String(intOr(k.tap_window_ms, 0)));
            putField(conf, 'key', k.name, 'long_press_ms', isBlank(k.long_press_ms) ? '' : String(intOr(k.long_press_ms, 0)));
            putField(conf, 'key', k.name, 'max_taps', isBlank(k.max_taps) ? '' : String(intOr(k.max_taps, 0)));
        });
        IniConf.blocks(conf, 'key').forEach(function (b) {
            if (!keyKeep[b.arg]) IniConf.removeBlock(conf, 'key', b.arg);
        });

        var s = m.slider;
        putField(conf, 'slider', '', 'backend', s.backend, 'auto');
        putField(conf, 'slider', '', 'proc_path', s.proc_path, '/proc/tristatekey/tri_state');
        putField(conf, 'slider', '', 'poll_ms', s.poll_ms, 200);
        putField(conf, 'slider', '', 'position_values', s.position_values, '1,2,3');
        putField(conf, 'slider', '', 'evdev_keys', s.evdev_keys, '603,602,601');
        putField(conf, 'slider', '', 'top', s.top || 'none', 'none');
        putField(conf, 'slider', '', 'middle', s.middle || 'none', 'none');
        putField(conf, 'slider', '', 'bottom', s.bottom || 'none', 'none');
        putField(conf, 'slider', '', 'block_original', b2s(s.block_original), 'false');
        putField(conf, 'slider', '', 'block_mode', s.block_mode, 'auto');
        putField(conf, 'slider', '', 'block_paths', s.block_paths);
        putField(conf, 'slider', '', 'block_hook', s.block_hook, 'block_restore.sh');
        putField(conf, 'slider', '', 'uevent_match', s.uevent_match);
        putField(conf, 'slider', '', 'uevent_map', s.uevent_map);
        return conf;
    }

    function isBlank(v) {
        return v === null || v === undefined || String(v).trim() === '';
    }

    return {
        GESTURES: GESTURES,
        KEY_NAMES: KEY_NAMES,
        load: load,
        apply: apply,
        labelOf: labelOf,
        maskToReplay: maskToReplay,
        replayToMask: replayToMask,
        intOr: intOr,
        boolOr: boolOr
    };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = SideModel;

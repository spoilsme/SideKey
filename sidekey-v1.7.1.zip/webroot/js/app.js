/* app.js - KernelSU / MMRL WebUI 主逻辑
 *
 * 依赖：iniconf.js（行级 ini 补丁）、model.js（配置模型）
 * 与设备通信：KernelSU 注入的 ksu.exec()，全部操作走 root shell。
 */
(function () {
    'use strict';

    // 数据目录：放在用户可见的 Android 目录，文件管理器能直接改
    // （/storage/emulated/0 是 noexec，脚本一律 sh 调用，不能直接执行）
    var DATA_DIR = '/storage/emulated/0/Android/sidekey';

    var PATHS = {
        data: DATA_DIR,
        cfg: DATA_DIR + '/config.conf',
        mod: '/data/adb/modules/sidekey',
        binMgr: '/data/adb/modules/sidekey/bin/sidekeyd',
        binData: DATA_DIR + '/bin/sidekeyd'
    };

    // 作者与发布信息
    var META = {
        author: 'spoilsme',
        repo: 'https://github.com/spoilsme/SideKey',
        issues: 'https://github.com/spoilsme/SideKey/issues'
    };

    var S = {
        api: null,
        text: '',
        model: null,
        scripts: [],
        scriptNames: {},     // 脚本文件名 -> 中文名（脚本第 2 行 # 名称: xxx）
        seqs: [],            // 多动作序列（带 # 序列: 1 头的脚本）
        seq: null,           // 正在编辑的序列
        seqBind: null,       // 从选择器进来时记住目标字段，保存后自动挂上去
        seqPick: null,       // 正在等用户选动作的回调
        apps: null,          // 已安装应用包名（点「打开应用…」时读一次）
        appNames: {},        // 包名 -> 中文名
        keys: null,          // --keys 输出：这台机器真实存在的按键
        bin: '',
        ver: '',
        running: false,
        pid: '',
        uinput: false,
        hasCfg: false,
        dirty: false,
        busy: false,
        devs: [],          // --status 输出的按键绑定
        sliderInfo: null,  // --status 输出的三段式后端
        devLoaded: false
    };

    var $ = function (id) { return document.getElementById(id); };
    var el = {};

    /* ------------------------------------------------------------------ */
    /* 基础工具                                                            */
    /* ------------------------------------------------------------------ */

    function esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    // 单引号包裹，内部单引号用 '\'' 转义
    function q(s) {
        return "'" + String(s).replace(/'/g, "'\\''") + "'";
    }

    function dirname(p) {
        var i = p.lastIndexOf('/');
        return i <= 0 ? '/' : p.slice(0, i);
    }

    // 脚本目录以配置里的 script_dir 为准，没读到配置时退回默认值
    function scriptsDir() {
        var g = S.model && S.model.general;
        var d = g && g.script_dir ? String(g.script_dir).trim() : '';
        return (d && d.charAt(0) === '/') ? d.replace(/\/+$/, '') : (PATHS.data + '/scripts');
    }

    function scriptPath(name) {
        return scriptsDir() + '/' + name;
    }

    // 内置动作打包在模块里，不在用户脚本目录
    function builtinPath(name) {
        return PATHS.mod + '/scripts/' + name;
    }

    // 日志文件以配置为准（@return 绝对路径）
    function logFile() {
        var g = S.model && S.model.general;
        var f = g && g.log_file ? String(g.log_file).trim() : '';
        return (f && f.charAt(0) === '/') ? f : (PATHS.data + '/sidekeyd.log');
    }

    function daemonOut() {
        return PATHS.data + '/daemon.out';
    }

    function getPath(path) {
        var parts = path.split('.');
        var o = S.model;
        for (var i = 0; i < parts.length; i++) {
            if (o == null) return null;
            o = o[parts[i]];
        }
        return o;
    }

    function setPath(path, value) {
        var parts = path.split('.');
        var o = S.model;
        for (var i = 0; i < parts.length - 1; i++) o = o[parts[i]];
        o[parts[parts.length - 1]] = value;
        markDirty();
    }

    function markDirty() {
        S.dirty = true;
        document.body.classList.add('dirty');
    }

    /* ------------------------------------------------------------------ */
    /* 与设备通信                                                          */
    /* ------------------------------------------------------------------ */

    function ksuApi() {
        try {
            if (typeof ksu !== 'undefined' && ksu && typeof ksu.exec === 'function') return ksu;
        } catch (e) { /* ignore */ }
        if (window.ksu && typeof window.ksu.exec === 'function') return window.ksu;
        if (window.mmrl && typeof window.mmrl.exec === 'function') return window.mmrl;
        return null;
    }

    var execSeq = 0;

    // KernelSU 个别版本会把回传的 stdout/stderr 再包一层 JSON 字符串字面量，解掉
    function unwrapArg(s) {
        if (typeof s === 'string' && s.length >= 2 && s.charAt(0) === '"' && s.charAt(s.length - 1) === '"') {
            try { return JSON.parse(s); } catch (e) { /* 不是 JSON 就原样返回 */ }
        }
        return s;
    }

    function normResult(v) {
        if (!v || typeof v !== 'object') return { errno: 1, stdout: '', stderr: 'empty' };
        return { errno: v.errno | 0, stdout: v.stdout || '', stderr: v.stderr || '' };
    }

    /* 三路自适应：
     *  A) Promise 风格 —— kernelsu npm 包装库、MMRL、以及本地测试桩
     *  B) 同步返回 {errno,stdout,stderr} —— 部分第三方管理器
     *  C) KernelSU 原生回调 —— ksu.exec(command, optionsJson, callbackFuncName)，
     *     回调签名兼容 (errno, stdout, stderr) 与 (id, errno, stdout, stderr) 两种
     * 统一都把回调名当第三个参数传进去：Promise/同步实现会忽略它，原生实现需要它。
     */
    function sh(cmd) {
        return new Promise(function (resolve) {
            var api = S.api || ksuApi();
            if (!api) {
                resolve({ errno: 127, stdout: '', stderr: 'WEBUI_SDK_MISSING' });
                return;
            }
            var cbName = '__sk_exec_' + Date.now().toString(36) + '_' + (execSeq++);
            var settled = false;
            function finish(v) {
                if (settled) return;
                settled = true;
                try { delete window[cbName]; } catch (e) { try { window[cbName] = undefined; } catch (e2) {} }
                resolve(normResult(v));
            }
            window[cbName] = function () {
                var a = Array.prototype.slice.call(arguments);
                var errno, stdout, stderr;
                if (a.length >= 4 && typeof a[0] === 'number') {
                    errno = a[1]; stdout = a[2]; stderr = a[3];   // (id, errno, stdout, stderr)
                } else {
                    errno = a[0]; stdout = a[1]; stderr = a[2];   // (errno, stdout, stderr)
                }
                finish({ errno: errno | 0, stdout: unwrapArg(stdout), stderr: unwrapArg(stderr) });
            };
            var r = null;
            try {
                r = api.exec(cmd, '{}', cbName);
            } catch (e) {
                r = null;
                if (!settled) finish({ errno: 1, stdout: '', stderr: String(e) });
                return;
            }
            if (r && typeof r.then === 'function') {
                r.then(function (v) { finish(v); }, function (e) { finish({ errno: 1, stdout: '', stderr: String(e) }); });
            } else if (r && typeof r === 'object') {
                finish(r);
            }
            // 其余（返回数字 id / undefined）：等原生回调触发 finish
        });
    }

    function out(r) {
        return ((r.stdout || '') + (r.stderr || '')).replace(/\s+$/, '');
    }

    function b64utf8(str) {
        var bytes = new TextEncoder().encode(str);
        var bin = '';
        for (var i = 0; i < bytes.length; i += 0x8000) {
            bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
        }
        return btoa(bin);
    }

    // 走 base64 写文件：避免任何引号/换行/中文的转义地狱
    function writeFile(path, text) {
        var data = b64utf8(text);
        return sh('mkdir -p ' + q(dirname(path)) + '; printf %s ' + q(data) + ' | base64 -d > ' + q(path))
            .then(function (r) {
                if (r.errno === 0) return r;
                return sh('printf %s ' + q(data) + ' | busybox base64 -d > ' + q(path));
            });
    }

    /* ------------------------------------------------------------------ */
    /* 状态                                                                */
    /* ------------------------------------------------------------------ */

    function refreshStatus() {
        var cmd = [
            'L=/dev/sidekeyd.lock; P=$(cat "$L" 2>/dev/null); A=0',
            'if [ -n "$P" ] && [ -d "/proc/$P" ] && grep -qa sidekeyd "/proc/$P/cmdline" 2>/dev/null; then A=1; fi',
            'echo "PID=$A:$P"',
            'B=' + q(PATHS.binMgr) + '; [ -x "$B" ] || B=' + q(PATHS.binData),
            'if [ -x "$B" ]; then echo "BIN=$B"; echo "VER=$("$B" --version 2>&1)"; fi',
            '[ -e /dev/uinput ] && echo "UINPUT=1" || echo "UINPUT=0"',
            '[ -f ' + q(PATHS.cfg) + ' ] && echo "CFG=1" || echo "CFG=0"'
        ].join('; ');

        return sh(cmd).then(function (r) {
            var lines = (r.stdout || '').split('\n');
            lines.forEach(function (line) {
                var i = line.indexOf('=');
                if (i < 0) return;
                var k = line.slice(0, i).trim();
                var v = line.slice(i + 1).trim();
                if (k === 'PID') {
                    var parts = v.split(':');
                    S.running = parts[0] === '1';
                    S.pid = parts[1] || '';
                } else if (k === 'BIN') S.bin = v;
                else if (k === 'VER') S.ver = v;
                else if (k === 'UINPUT') S.uinput = v === '1';
                else if (k === 'CFG') S.hasCfg = v === '1';
            });
            renderStatus();
            return r;
        });
    }

    function renderStatus() {
        var pill = el.pill, txt = el.pillText;
        if (!S.api) {
            pill.className = 'pill off';
            txt.textContent = '需在 KernelSU 中打开';
            el.statusText.textContent = '当前页面没有拿到 root shell 接口';
            return;
        }
        if (!S.bin) {
            pill.className = 'pill off';
            txt.textContent = '缺少二进制';
            el.statusText.textContent = '未找到 sidekeyd，请重新刷入模块';
            return;
        }
        if (S.running) {
            pill.className = 'pill on';
            txt.textContent = '运行中';
            el.statusText.textContent = 'sidekeyd ' + (S.ver || '');
        } else {
            pill.className = 'pill off';
            txt.textContent = '未运行';
            el.statusText.textContent = '守护进程没有启动，改完配置点「保存并重启」';
        }
    }

    function loadScripts() {
        return sh('ls -1 ' + q(scriptsDir()) + ' 2>/dev/null')
            .then(function (r) {
                S.scripts = (r.stdout || '').split('\n')
                    .map(function (s) { return s.trim(); })
                    .filter(function (s) { return s && /\.sh$/i.test(s); });
                var dl = $('dl-scripts');
                if (dl) {
                    dl.innerHTML = S.scripts.map(function (n) { return '<option value="' + esc(n) + '"></option>'; }).join('');
                }
                return loadScriptNames();
            });
    }

    // 自定义脚本的中文名写在文件第 2 行：# 名称: 打开酷安
    // 内置脚本有 LIB_NAMES，不用读文件；只读"自己的"那几个，一次命令搞定
    function loadScriptNames() {
        var mine = S.scripts.filter(function (n) { return !LIB_NAMES[n]; });
        S.scriptNames = {};
        S.seqs = [];
        if (!mine.length) { if (S.model) renderScripts(); return Promise.resolve(); }
        var cmd = 'cd ' + q(scriptsDir()) + ' 2>/dev/null; for f in ' +
            mine.map(function (n) { return q(n); }).join(' ') + '; do echo "@@$f"; head -n 6 "$f" 2>/dev/null; done';
        return sh(cmd).then(function (r) {
            var cur = null;
            (r.stdout || '').split('\n').forEach(function (line) {
                if (line.indexOf('@@') === 0) { cur = line.slice(2).trim(); return; }
                if (!cur) return;
                var m = /^#\s*名称:\s*(.+)$/.exec(line);
                if (m && !S.scriptNames[cur]) S.scriptNames[cur] = m[1].trim();
                if (/^#\s*序列:\s*1\s*$/.test(line) && S.seqs.indexOf(cur) < 0) S.seqs.push(cur);
            });
            if (S.model) { renderScripts(); renderKeys(); }
        });
    }

    function loadConfig() {
        return sh('cat ' + q(PATHS.cfg)).then(function (r) {
            if (r.errno !== 0 || !(r.stdout || '').length) {
                S.text = '';
                S.model = null;
                S.hasCfg = false;
                renderAll();
                return;
            }
            S.text = (r.stdout || '').replace(/\r\n/g, '\n');
            S.model = SideModel.load(S.text);
            S.hasCfg = true;
            S.dirty = false;
            document.body.classList.remove('dirty');
            renderAll();
        });
    }

    /* ------------------------------------------------------------------ */
    /* 渲染：按键                                                          */
    /* ------------------------------------------------------------------ */

    // 引擎自己判断"这个键挂在哪个设备、要不要独占"，首页只做展示
    function loadDeviceStatus() {
        if (!S.bin) {
            S.devLoaded = true;
            S.devs = [];
            renderKeys();
            return Promise.resolve();
        }
        return sh(q(S.bin) + ' --status 2>&1').then(function (r) {
            var lines = (r.stdout || '').split('\n');
            var devs = [];
            var slider = null;
            lines.forEach(function (line) {
                line = line.trim();
                if (line.indexOf('KEY=') === 0) {
                    var p = line.slice(4).split('|');
                    devs.push({
                        name: p[0], code: p[1], dev: p[2] || '', path: p[3] || '',
                        gate: p[4] === '1', grab: p[5] === '1'
                    });
                } else if (line.indexOf('SLIDER=') === 0) {
                    var q2 = line.slice(7).split('|');
                    slider = { backend: q2[0], path: q2[1] || '', raw: q2[2] || '' };
                } else if (line.indexOf('UINPUT=') === 0) {
                    S.uinput = line.slice(7).trim() === '1';
                }
            });
            S.devs = devs;
            S.sliderInfo = slider;
            S.devLoaded = true;
            renderKeys();
            renderGeneral();
            return loadKeys().then(function () { renderGeneral(); });   // 设置页的按键扫描也要跟着刷新
        });
    }

    function devOf(name) {
        for (var i = 0; i < S.devs.length; i++) if (S.devs[i].name === name) return S.devs[i];
        return null;
    }

    // 顶部识别卡：每个键挂在哪个设备、独占状态、三段式识别结果
    function deviceCard() {
        if (!S.devLoaded) {
            return '<div class="card dev-card"><div class="card-head"><div class="t">自动识别</div>' +
                '<div class="spacer"></div><span class="tag">读取中…</span></div></div>';
        }
        var rows = S.devs.map(function (d) {
            var label = SideModel.labelOf(d.name);
            var state, cls;
            if (!d.dev) { state = '未找到设备'; cls = 'warn'; }
            else if (d.grab) { state = '独占中 · 多击拦截生效'; cls = 'ok'; }
            else if (d.gate) { state = '设备未独占 · 只能叠加'; cls = 'warn'; }
            else { state = '原样透传'; cls = ''; }
            return '<li><span class="dk">' + esc(label) + '</span>' +
                '<span class="dv">' + esc(d.dev || '—') + '</span>' +
                '<span class="ds ' + cls + '">' + esc(state) + '</span></li>';
        }).join('');
        var sl = S.sliderInfo;
        var slText = !sl || sl.backend === 'none' ? '没找到三段式节点'
            : (sl.backend === 'proc' ? 'proc 节点（当前值 ' + esc(sl.raw) + '）'
                : (sl.backend === 'evdev' ? '按键上报 · ' + esc(sl.path) : esc(sl.backend)));

        return '<div class="card dev-card">' +
            '<div class="card-head"><div class="t">自动识别</div><div class="spacer"></div>' +
                '<button class="mini" data-act="reload-dev">重新识别</button></div>' +
            '<ul class="devlist">' + (rows || '<li class="muted">没有读到按键</li>') +
                '<li><span class="dk">三段式</span><span class="dv">' + slText + '</span></li>' +
            '</ul>' +
            (!S.uinput ? '<div class="note warn" style="margin:6px 0 0"><div><b>uinput 不可用</b>：多击拦截暂时不生效，双击会同时触发原功能。</div></div>' : '') +
        '</div>';
    }

    // 动作行：显示中文名的按钮（点开选择器）+ 清空；配置里存的仍是脚本名
    function actionRow(k, i, g) {
        var bind = 'keys.' + i + '.' + g.field;
        var val = k[g.field];
        var isNone = !val || val === 'none';
        return '<div class="row">' +
            '<label>' + g.label + '</label>' +
            '<div class="grow"><div style="display:flex;gap:6px">' +
                '<button class="act-btn' + (isNone ? ' is-none' : '') + '" data-act="pick" data-bind="' + bind +
                    '" data-cap="' + esc(k.label + ' · ' + g.label) + '">' + esc(actionLabel(val)) + '</button>' +
                (isNone ? '' : '<button class="mini" data-act="clear-act" data-bind="' + bind + '" aria-label="清空">✕</button>') +
            '</div></div>' +
        '</div>';
    }

    // 手势行：只显示配了动作的；没配的收进「＋ 手势」chips，要用再加
    function gestureRows(k, i) {
        var bind = function (g) { return 'keys.' + i + '.' + g.field; };
        var rows = SideModel.GESTURES.filter(function (g) {
            var v = k[g.field];
            return v && v !== 'none';
        }).map(function (g) { return actionRow(k, i, g); }).join('');
        var chips = SideModel.GESTURES.filter(function (g) {
            var v = k[g.field];
            return !v || v === 'none';
        }).map(function (g) {
            return '<button class="chip sm" data-act="pick" data-bind="' + bind(g) +
                '" data-cap="' + esc(k.label + ' · ' + g.label) + '">＋' + esc(g.label) + '</button>';
        }).join('');
        return '<div class="gesture-list">' + rows + '</div>' +
            (chips ? '<div class="row" style="align-items:flex-start"><label style="visibility:hidden">·</label>' +
                '<div class="grow"><div class="chips">' + chips + '</div></div></div>' : '');
    }

    function advRows(k, i) {
        return '<div class="row"><label>连击窗口</label><div class="grow"><input type="number" inputmode="numeric" data-bind="keys.' + i +
            '.tap_window_ms" value="' + esc(k.tap_window_ms) + '" placeholder="跟随全局"><div class="hint">两次按下的间隔小于它才算连击，毫秒</div></div></div>' +
            '<div class="row"><label>长按阈值</label><div class="grow"><input type="number" inputmode="numeric" data-bind="keys.' + i +
            '.long_press_ms" value="' + esc(k.long_press_ms) + '" placeholder="跟随全局"><div class="hint">只在你配了长按动作时生效</div></div></div>' +
            '<div class="row"><label>最多次数</label><div class="grow"><input type="number" inputmode="numeric" data-bind="keys.' + i +
            '.max_taps" value="' + esc(k.max_taps) + '" placeholder="跟随全局"><div class="hint">1–5，越大越容易把快速连按识别成多击</div></div></div>';
    }

    function newKey(name) {
        var vol = (name === 'volume_up' || name === 'volume_down');
        return {
            name: name, label: SideModel.labelOf(name),
            single: 'none', double: 'none', triple: 'none', four: 'none', five: 'none', long: 'none',
            gate_multi: vol, hold_forward: vol,
            tap_window_ms: '', long_press_ms: '', max_taps: ''
        };
    }

    // 监听 5 秒，把按到的键自动加进来（解析 sidekeyd --monitor 的输出）
    function listenAddKeys() {
        var btn = document.querySelector('[data-act="listen-add"]');
        if (btn) { btn.disabled = true; btn.textContent = '监听中…'; }
        toast('请现在按几下想添加的按键（听 5 秒）');
        var done = function (msg, isErr) {
            if (btn) { btn.disabled = false; btn.textContent = '按按键自动添加'; }
            toast(msg, !!isErr);
        };
        if (!S.bin) { done('找不到 sidekeyd', true); return; }
        sh(q(S.bin) + ' --monitor -s 5 2>&1').then(function (r) {
            var text = out(r);
            var seen = {};
            var re = /EV_KEY\s+code=(\d+)\s+\S+\s+value=1/g, m;
            while ((m = re.exec(text))) seen[parseInt(m[1], 10)] = true;
            var added = [], unknown = [];
            Object.keys(seen).map(Number).forEach(function (code) {
                var hit = null;
                SideModel.KEY_NAMES.forEach(function (n) { if (n.code === code) hit = n; });
                if (!hit) { unknown.push(code); return; }
                if (S.model.keys.some(function (k) { return k.name === hit.name; })) return;  // 已加过
                S.model.keys.push(newKey(hit.name));
                added.push(hit.label);
            });
            markDirty();
            renderKeys();
            if (added.length) done('已添加：' + added.join('、') + '，配好动作记得保存');
            else if (unknown.length) done('按到的键（' + unknown.join(', ') + '）不在内置名单里，可在配置文件里用 code = 数字 手写', true);
            else done('5 秒内没有按到任何键', true);
        });
    }

    function renderKeys() {
        var v = $('view-keys');
        if (!S.model) {
            v.innerHTML = '<div class="empty">读不到配置文件<code>' + PATHS.cfg + '</code>' +
                '<code>请确认模块已经正确刷入并至少重启过一次</code></div>';
            return;
        }
        var html = deviceCard();

        // 音量键方向：独立一块，一个开关管全局（默认自动判断 = 自动修复）
        var gSwap = (S.model.general && S.model.general.volume_swap) || 'auto';
        html += '<div class="card"><div class="card-head"><div class="t">音量键方向</div></div>' +
            '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">方向反了就对调</label>' +
            '<button class="switch" role="switch" data-act="vol-swap" aria-checked="' +
            (gSwap === 'on' ? 'true' : 'false') + '"></button></div>' +
            '<div class="hint">平时不用管：守护进程会读系统按键布局自动修正方向（自动修复）。' +
            '只有按了音量键发现方向不对时才打开它，点底部「保存并重启」生效。</div></div>';
        var gw = (S.model.general && S.model.general.tap_window_ms) || 220;

        S.model.keys.forEach(function (k, i) {
            var isPower = k.name === 'power';
            var multi = ['double', 'triple', 'four', 'five'].some(function (f) {
                return k[f] && k[f] !== 'none';
            });

            html += '<div class="card">' +
                '<div class="card-head">' +
                    '<div class="t">' + esc(k.label) + '</div>' +
                    '<div class="spacer"></div>' +
                    '<button class="mini" data-act="del-key" data-i="' + i + '">删除</button>' +
                '</div>';

            if (isPower) {
                html += '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">拦截电源键（双击只跑脚本）</label>' +
                    '<button class="switch danger" role="switch" data-toggle="keys.' + i + '.intercept" aria-checked="' +
                    (k.intercept ? 'true' : 'false') + '"></button></div>';
                if (k.intercept) {
                    html += '<div class="note warn" style="margin:0 0 4px"><div><b>实验性</b>：单击亮屏/息屏会慢约 ' +
                        esc(String(gw)) + ' 毫秒，长按关机菜单多等约半秒，电源+音量下截屏会失效。</div></div>';
                }
            } else {
                html += '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">多击时拦下原功能</label>' +
                    '<button class="switch" role="switch" data-toggle="keys.' + i + '.gate_multi" aria-checked="' +
                    (k.gate_multi ? 'true' : 'false') + '"></button></div>';
                if (k.gate_multi && multi && S.devLoaded) {
                    var d = devOf(k.name);
                    if (!d || !d.grab) {
                        html += '<div class="note warn" style="margin:6px 0 0"><div>这个键所在的设备当前没被独占，' +
                            '多击拦截暂时不生效，双击仍会触发原功能。看「设置 → 按键扫描」确认状态。</div></div>';
                    }
                }
            }

            html += gestureRows(k, i) +
                '<details class="adv"><summary>高级 · 连击窗口 / 长按阈值</summary>' + advRows(k, i) + '</details>' +
            '</div>';
        });

        var used = {};
        S.model.keys.forEach(function (k) { used[k.name] = true; });
        var rest = SideModel.KEY_NAMES.filter(function (n) { return !used[n.name]; });

        html += '<div class="card">' +
            '<div class="card-head"><div class="t">添加按键</div></div>' +
            '<div class="row"><div class="grow">按几下想添加的实体按键，监听 5 秒自动识别</div>' +
            '<button class="mini" data-act="listen-add">按按键添加</button></div>' +
            (rest.length ?
                '<details class="adv"><summary>识别不到？手动选一个</summary><div class="row"><div class="grow">' +
                '<select id="add-key-sel">' +
                rest.map(function (n) { return '<option value="' + n.name + '">' + n.label + '</option>'; }).join('') +
                '</select></div><button class="mini" data-act="add-key">添加</button></div></details>' : '') +
        '</div>';

        html += sliderCard() + chordsSection();

        v.innerHTML = html;
    }

    /* ------------------------------------------------------------------ */
    /* 三段式 / 组合键：作为「按键」页的下部区块                             */
    /* ------------------------------------------------------------------ */

    function sliderCard() {
        if (!S.model) return '';
        var s = S.model.slider;
        var sel = function (bind, val, list) {
            return '<select data-bind="' + bind + '">' + list.map(function (o) {
                return '<option value="' + o[0] + '"' + (o[0] === val ? ' selected' : '') + '>' + o[1] + '</option>';
            }).join('') + '</select>';
        };

        var html = '<div class="section-title">三段式</div>' +
        '<div class="card">' +
            '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">屏蔽原有功能</label>' +
                '<button class="switch danger" role="switch" data-toggle="slider.block_original" aria-checked="' + (s.block_original ? 'true' : 'false') + '"></button>' +
            '</div>' +
            '<div class="row"><label>屏蔽方式</label><div class="grow">' +
                sel('slider.block_mode', s.block_mode, [['auto', 'auto'], ['mount', 'mount'], ['chmod', 'chmod'], ['hook', 'hook'], ['none', 'none']]) +
            '</div></div>';
        var positions = ['top', 'middle', 'bottom'].map(function (f, idx) {
            var label = ['上', '中', '下'][idx];
            var isNone = !s[f] || s[f] === 'none';
            return '<div class="row"><label>' + label + '</label><div class="grow"><div style="display:flex;gap:6px">' +
                '<button class="act-btn' + (isNone ? ' is-none' : '') + '" data-act="pick" data-bind="slider.' + f +
                    '" data-cap="三段式 · ' + label + '">' + esc(actionLabel(s[f])) + '</button>' +
                (isNone ? '' : '<button class="mini" data-act="clear-act" data-bind="slider.' + f + '" aria-label="清空">✕</button>') +
            '</div></div></div>';
        }).join('');
        html += positions +
            '<details class="adv"><summary>高级 · 检测节点与屏蔽路径</summary>' +
                '<div class="row"><label>节点</label><div class="grow"><input type="text" data-bind="slider.proc_path" value="' + esc(s.proc_path) + '" spellcheck="false"></div></div>' +
                '<div class="row"><label>轮询</label><div class="grow"><input type="number" inputmode="numeric" data-bind="slider.poll_ms" value="' + esc(s.poll_ms) + '"></div></div>' +
                '<div class="row"><label>位置值</label><div class="grow"><input type="text" data-bind="slider.position_values" value="' + esc(s.position_values) + '"></div></div>' +
                '<div class="row"><label>evdev 码</label><div class="grow"><input type="text" data-bind="slider.evdev_keys" value="' + esc(s.evdev_keys) + '"></div></div>' +
                '<div class="row" style="align-items:flex-start"><label>路径</label><div class="grow"><textarea data-bind="slider.block_paths" spellcheck="false">' + esc(s.block_paths) + '</textarea></div></div>' +
                '<div class="row"><label>hook</label><div class="grow"><input type="text" data-bind="slider.block_hook" value="' + esc(s.block_hook) + '" list="dl-scripts" spellcheck="false"></div></div>' +
                '<div class="row"><label>uevent</label><div class="grow"><input type="text" data-bind="slider.uevent_match" value="' + esc(s.uevent_match) + '" placeholder="tri_state_key"></div></div>' +
                '<div class="row"><label>映射</label><div class="grow"><input type="text" data-bind="slider.uevent_map" value="' + esc(s.uevent_map) + '" placeholder="USB=0:3,USB-HOST=0:2"></div></div>' +
            '</details>' +
        '</div>';
        return html;
    }

    // 兼容旧调用：合并后统一重画按键页
    function renderSlider() { renderKeys(); }

    function chordsSection() {
        if (!S.model) return '';
        S.model.chords = S.model.chords || [];

        var html = '<div class="section-title">组合键</div>' +
            '<div class="card"><div class="card-head">' +
                '<div class="t">同时按住几个键执行动作</div><div class="spacer"></div>' +
                '<button class="mini" data-act="add-chord">新建</button></div></div>';

        S.model.chords.forEach(function (c, i) {
            var names = (c.keys || []).map(keyLabelOf).join(' + ');
            var chips = chordKeys().map(function (kn) {
                var on = (c.keys || []).indexOf(kn.name) >= 0;
                return '<button class="chip sm" data-act="chord-key" data-i="' + i + '" data-k="' + kn.name +
                    '" aria-pressed="' + (on ? 'true' : 'false') + '">' + esc(kn.label) + '</button>';
            }).join('');
            var isNone = !c.action || c.action === 'none';
            html += '<div class="card"><div class="card-head">' +
                '<div><div class="t">' + esc(names || '请勾选按键') + '</div>' +
                '<div class="s">' + (c.ordered ? '按顺序依次按下' : '同时按住') +
                ' · ' + (c.keys || []).length + ' 个键</div></div>' +
                '<div class="spacer"></div>' +
                '<button class="mini" data-act="del-chord" data-i="' + i + '">删除</button>' +
            '</div>' +
            '<div class="row" style="align-items:flex-start"><label>按键</label><div class="grow"><div class="chips">' +
                chips + '</div><div class="hint">至少两个。勾选顺序 = 判定顺序（开了「按顺序」才生效）</div></div></div>' +
            '<div class="row"><label>动作</label><div class="grow"><div style="display:flex;gap:6px">' +
                '<button class="act-btn' + (isNone ? ' is-none' : '') + '" data-act="pick-chord" data-i="' + i +
                    '" data-cap="组合键 · ' + esc(names) + '">' + esc(actionLabel(c.action)) + '</button>' +
                (isNone ? '' : '<button class="mini" data-act="clear-chord" data-i="' + i + '" aria-label="清空">✕</button>') +
            '</div></div></div>' +
            '<div class="row"><label>判定窗口</label><div class="grow"><input type="number" inputmode="numeric" data-bind="chords.' +
                i + '.window_ms" value="' + esc(c.window_ms) + '"></div></div>' +
            '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">按顺序依次按下</label>' +
                '<button class="switch" role="switch" data-toggle="chords.' + i + '.ordered" aria-checked="' +
                (c.ordered ? 'true' : 'false') + '"></button></div>' +
            '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">吞掉这些键的原功能</label>' +
                '<button class="switch danger" role="switch" data-toggle="chords.' + i + '.block" aria-checked="' +
                (c.block ? 'true' : 'false') + '"></button></div>' +
            '</div>';
        });

        return html;
    }

    // 兼容旧调用
    function renderChords() { renderKeys(); }

    /* ------------------------------------------------------------------ */
    /* 渲染：设置（全局 + 工具合并）                                        */
    /* ------------------------------------------------------------------ */

    function renderGeneral() {
        var v = $('view-general');
        if (!v) return;
        if (!S.model) { v.innerHTML = '<div class="empty">读不到配置文件</div>'; return; }
        var g = S.model.general;

        var html = '<div class="card">' +
            '<div class="card-head"><div class="t">手势时序</div></div>' +
            '<div class="row"><label>连击窗口</label><div class="grow"><input type="number" inputmode="numeric" data-bind="general.tap_window_ms" value="' + esc(g.tap_window_ms) + '"><div class="hint">两次按下的间隔小于它才算连击，60–1000 毫秒</div></div></div>' +
            '<div class="row"><label>长按阈值</label><div class="grow"><input type="number" inputmode="numeric" data-bind="general.long_press_ms" value="' + esc(g.long_press_ms) + '"><div class="hint">按住多久算长按</div></div></div>' +
            '<div class="row"><label>最多次数</label><div class="grow"><select data-bind="general.max_taps">' +
                [1, 2, 3, 4, 5].map(function (n) {
                    return '<option value="' + n + '"' + (g.max_taps === n ? ' selected' : '') + '>' + n + ' 次</option>';
                }).join('') +
            '</select></div></div>' +
        '</div>' +

        '<div class="card">' +
            '<div class="card-head"><div class="t">按键扫描</div><div class="spacer"></div>' +
                '<button class="mini" data-act="scan-keys">重新扫描</button></div>' +
            '<div class="hint" style="margin-bottom:8px">这台机器上真实存在的按键（列表里没有的键监听不出来，可以在「按键」页手动添加）</div>' +
            '<ul class="devlist" id="scan-list">' + keyScanRows() + '</ul>' +
        '</div>' +

        '<div class="card">' +
            '<div class="card-head"><div class="t">诊断</div><div class="spacer"></div>' +
                '<button class="mini" data-act="monitor">监听 6 秒</button>' +
                '<button class="mini" data-act="check">校验配置</button></div>' +
            '<div class="hint" style="margin-bottom:8px">监听：相当于 evtest，按键没反应时看有没有事件上报。校验：保存时会自动跑。</div>' +
            '<pre class="out" id="out-monitor" hidden></pre>' +
            '<pre class="out" id="out-check" hidden></pre>' +
        '</div>' +

        '<div class="card">' +
            '<div class="card-head"><div class="t">目录与日志</div><div class="spacer"></div>' +
                '<button class="mini" data-go="log">去「日志」页</button></div>' +
            '<div class="row"><label>脚本目录</label><div class="grow"><input type="text" data-bind="general.script_dir" value="' + esc(g.script_dir) + '" spellcheck="false"></div></div>' +
            '<div class="row"><label>日志文件</label><div class="grow"><input type="text" data-bind="general.log_file" value="' + esc(g.log_file || '') + '" spellcheck="false"></div></div>' +
            '<div class="row"><label>日志状态</label><div class="grow"><span class="pill ' + (g.log_enabled ? 'on' : 'off') + '">' +
                (g.log_enabled ? '正在记录' : '已关闭') + '</span></div></div>' +
        '</div>' +

        '<div class="card">' +
            '<div class="card-head"><div class="t">锁屏密码自动输入</div></div>' +
            '<div class="row"><label>密码数字</label><div class="grow"><input type="text" inputmode="numeric" id="wx-digits" placeholder="你的锁屏密码数字，例如 258012" spellcheck="false">' +
                '<div class="hint">填了它，脚本会自动在密码键盘上定位每个数字逐个点下，不用量坐标。<b>加密存储</b>：保存后密码以密文形式只存在本机，每次保存重新生成随机密钥（一次一密），密钥放在仅 root 可读的系统目录</div></div></div>' +
            '<div class="row"><label>解锁后自动输</label><div class="grow"><div style="display:flex;gap:8px;align-items:center">' +
                '<button class="switch" role="switch" id="wx-chain" data-act="pwd-chain" aria-checked="false"></button>' +
                '<button class="mini" data-act="pwd-save">保存密码配置</button></div>' +
                '<div class="hint">开了它：锁屏付款码解锁到密码界面后自动把密码输完，一键直达付款码。点「保存密码配置」立即生效，不用重启</div></div></div>' +
            '<div class="row"><div class="grow">🔒 隐私说明<div class="hint">你的锁屏密码<b>只保存在这台手机的本地存储</b>里，且是加密存放（普通应用读到配置文件也还原不出密码）；本模块<b>不联网、不上传、不收集</b>任何密码信息，卸载模块即全部清除</div></div></div>' +
        '</div>' +

        '<div class="card">' +
            '<div class="card-head"><div class="t">电源键+音量减截图</div></div>' +
            '<div class="row"><div class="grow">保留系统截图组合键<div class="hint">音量下/电源键配了多击拦截后，系统自带的「电源键+音量减」截图会失效。开了它：这两个键一起按时立即放行给系统截图，该次按压不执行你配的动作。保存并重启守护进程后生效</div></div>' +
                '<button class="switch" role="switch" data-toggle="general.keep_screenshot" aria-checked="' +
                (g.keep_screenshot ? 'true' : 'false') + '"></button></div>' +
        '</div>' +

        '<div class="card">' +
            '<div class="card-head"><div class="t">手电筒修复</div></div>' +
            '<div class="row"><div class="grow">控制中心手电筒点不亮时用<div class="hint">v1.7.1 起最大亮度改成「官方服务点亮 → 再拉满亮度」，正常使用不会再把控制中心搞坏，平时不用管。万一哪天点不亮了（换固件、刷机后），点这里复位闪光灯驱动 + 重启相机 HAL，约 10 秒恢复，<b>不用重启手机</b></div></div>' +
                '<button class="mini" data-act="torch-repair">修复手电筒</button></div>' +
        '</div>' +

        '<div class="card">' +
            '<div class="card-head"><div class="t">危险操作</div></div>' +
            '<div class="row"><div class="grow">恢复默认配置<div class="hint">模块模板覆盖当前配置，修改会丢</div></div>' +
                '<button class="mini" data-act="defaults">恢复</button></div>' +
            '<div class="row"><div class="grow">清空日志</div>' +
                '<button class="mini" data-act="clearlog">清空</button></div>' +
            '<div class="row"><div class="grow">重启守护进程</div>' +
                '<button class="mini" data-act="restart">重启</button></div>' +
        '</div>';

        v.innerHTML = html;

        // 读锁屏密码配置回填（wx_password.conf 不在 sidekey.conf 里，单独读）。
        // 加密格式（enc=）不回显明文，只提示已设置几位；旧明文 digits= 才回填。
        sh('cat ' + q(PATHS.data + '/wx_password.conf') + ' 2>/dev/null').then(function (r) {
            var txt = out(r) || '';
            var inp = $('wx-digits');
            var encM = txt.match(/^enc=(\d+)/m);
            if (inp && encM) {
                inp.value = '';
                inp.placeholder = '已加密保存（' + encM[1].length + ' 位）。输入新密码可覆盖';
            } else if (inp) {
                var m = txt.match(/^digits=(\d+)/m);
                if (m) {
                    inp.value = m[1];
                    inp.placeholder = '当前还是明文格式，点「保存密码配置」转为加密存储';
                }
            }
            var cb = $('wx-chain');
            if (cb && /^chain=1/m.test(txt)) cb.setAttribute('aria-checked', 'true');
        });
    }

    // 按键扫描：只列按键（名字 + 键码 + 设备），不再倒一屏输入设备
    function keyScanRows() {
        if (!S.devLoaded) return '<li class="muted">正在读取…</li>';
        if (!S.keys || !S.keys.length) {
            return '<li class="muted">没扫到按键。点「重新扫描」，或去「按键」页按几下实体键试试</li>';
        }
        return S.keys.map(function (k) {
            return '<li><span class="dk">' + esc(keyLabelOf(k.name)) + '</span>' +
                '<span class="dv">' + esc('code ' + k.code) + '</span>' +
                '<span class="ds">' + esc(k.dev || '—') + '</span></li>';
        }).join('');
    }

    // 兼容旧调用：工具卡已并入设置页
    function renderTools() { renderGeneral(); }

    function renderLog() {
        var g = (S.model && S.model.general) || {};
        var on = !!g.log_enabled;
        var html = '';

        html += '<div class="card">' +
            '<div class="card-head"><div class="t">日志开关</div><div class="spacer"></div>' +
                '<span class="pill ' + (on ? 'on' : 'off') + '">' + (on ? '正在记录' : '已关闭') + '</span>' +
            '</div>' +
            '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">总开关（写日志）</label>' +
                '<button class="switch" role="switch" data-toggle="general.log_enabled" aria-checked="' +
                (on ? 'true' : 'false') + '"></button></div>' +
            '<div class="row"><div class="grow"></div>' +
                '<button class="mini" data-act="log-debug-on">一键开启调试（等级 3）</button>' +
                '<button class="mini" data-act="log-off">关闭日志</button>' +
            '</div>' +
        '</div>';

        html += '<div class="card">' +
            '<div class="card-head"><div class="t">记录内容</div></div>' +
            '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">脚本输出（脚本里的 echo / 报错）</label>' +
                '<button class="switch" role="switch" data-toggle="general.log_script" aria-checked="' +
                (g.log_script ? 'true' : 'false') + '"></button></div>' +
            '<div class="hint" style="margin:0 0 8px">给脚本一个日志通道，脚本里的 echo 才能落盘</div>' +
            '<div class="row"><label style="width:auto;flex:1;color:var(--fg)">启动输出 daemon.out</label>' +
                '<button class="switch" role="switch" data-toggle="general.log_daemon_out" aria-checked="' +
                (g.log_daemon_out ? 'true' : 'false') + '"></button></div>' +
            '<div class="hint" style="margin:0 0 8px">开机没反应时看它</div>' +
            '<div class="row"><label>日志等级</label><div class="grow"><select data-bind="general.log_level">' +
                [[0, '0 · 只记错误'], [1, '1 · 加警告'], [2, '2 · 信息（默认）'], [3, '3 · 调试（最详细）']].map(function (o) {
                    return '<option value="' + o[0] + '"' + (g.log_level === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
                }).join('') +
            '</select></div></div>' +
            '<div class="row"><label>自动清理</label><div class="grow"><select data-bind="general.log_keep_min">' +
                [[0, '不清理'], [60, '1 小时'], [240, '4 小时（默认）'], [720, '12 小时'], [1440, '1 天']].map(function (o) {
                    return '<option value="' + o[0] + '"' + (g.log_keep_min === o[0] ? ' selected' : '') + '>' + o[1] + '</option>';
                }).join('') +
            '</select><div class="hint">日志超过这个时长就清空重写，不会越积越大</div></div></div>' +
            '<div class="row"><label>日志文件</label><div class="grow">' +
                '<input type="text" data-bind="general.log_file" value="' + esc(g.log_file || '') + '" spellcheck="false"></div></div>' +
        '</div>';

        if (!on) {
            html += '<div class="note warn"><div>日志已关闭：下面的内容不会更新。要排查问题，先打开上面的开关，' +
                '点底部「保存并重启」，再按键试一次。</div></div>';
        }

        html += '<div class="card">' +
                '<div class="card-head"><div class="t">守护进程日志</div><div class="spacer"></div>' +
                '<button class="mini" data-act="clearlog">清空</button>' +
                '<button class="mini" data-act="log-refresh">刷新</button></div>' +
                '<pre class="out" id="out-log">正在读取…</pre>' +
            '</div>' +
            '<div class="card">' +
                '<div class="card-head"><div class="t">启动输出 daemon.out</div><div class="spacer"></div>' +
                '<button class="mini" data-act="out-refresh">刷新</button></div>' +
                '<pre class="out" id="out-daemon">正在读取…</pre>' +
            '</div>';

        $('view-log').innerHTML = html;
    }

    /* ------------------------------------------------------------------ */
    /* 渲染：脚本管理 / 简介                                                */
    /* ------------------------------------------------------------------ */

    // 脚本模板：给不会写 sh 的人一个能直接用的起点
    var SCRIPT_TPLS = [
        {
            id: 'camera', name: 'open_camera.sh', title: '打开相机',
            body: '#!/system/bin/sh\n' +
                  '# 名称: 打开相机\n' +
                  'am start -a android.media.action.STILL_IMAGE_CAMERA >/dev/null 2>&1\n'
        },
        {
            id: 'app', name: 'open_app.sh', title: '打开某个应用',
            body: '#!/system/bin/sh\n' +
                  '# 名称: 打开应用\n' +
                  '# 把包名换成你要打开的 App（不知道包名就用「选择动作 → 打开应用…」直接选）\n' +
                  'monkey -p com.tencent.mm -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1\n'
        },
        {
            id: 'blank', name: 'my_action.sh', title: '空白模板',
            body: '#!/system/bin/sh\n' +
                  '# 名称: 我的动作\n' +
                  '# $1=按键名  $2=手势  $3=连击次数  $4=滑块位置\n' +
                  '# 下面写你要执行的命令，和在 adb shell 里敲的一模一样\n\n'
        }
    ];

    function tplOf(id) {
        for (var i = 0; i < SCRIPT_TPLS.length; i++) if (SCRIPT_TPLS[i].id === id) return SCRIPT_TPLS[i];
        return SCRIPT_TPLS[2];
    }

    function renderScripts() {
        var v = $('view-scripts');
        if (!v) return;
        var html = '<div class="note"><div>这里管理 <code class="inline">' + esc(PATHS.data) + '/scripts/</code> 下的动作脚本。' +
            '改完内容不用重启，下一次触发就用新逻辑。</div></div>';

        html += '<div class="card">' +
            '<div class="card-head"><div class="t">我的脚本</div><div class="spacer"></div>' +
                '<button class="mini" data-act="new-script">新建脚本</button></div>';

        var mine = S.scripts.filter(function (n) { return !LIB_NAMES[n]; });
        if (!mine.length) {
            html += '<div class="hint">还没有自己的脚本。点「新建脚本」挑个模板，或者直接在「按键」页选内置动作。</div>';
        } else {
            mine.forEach(function (n) {
                var nm = S.scriptNames[n];
                var isSeq = S.seqs.indexOf(n) >= 0;
                html += '<div class="card"><div class="card-head">' +
                    '<div><div class="t">' + esc(nm || n.replace(/\.sh$/i, '')) + '</div>' +
                    '<div class="s">' + esc(n) + ' · ' + (isSeq ? '多动作序列' : '自定义') + '</div></div>' +
                    '<div class="spacer"></div>' +
                    '<button class="mini" data-act="run-script" data-f="' + esc(n) + '">试运行</button>' +
                    '<button class="mini" data-act="edit-script" data-f="' + esc(n) + '">编辑</button>' +
                    '<button class="mini" data-act="del-script" data-f="' + esc(n) + '">删除</button>' +
                '</div></div>';
            });
        }
        html += '</div>';

        // 多动作（序列）区：和脚本同一页
        html += seqSection();

        // 内置脚本：打包在模块里，不依赖用户目录的 ls 结果
        var builtinNames = [];
        LIB.forEach(function (g) {
            g[1].forEach(function (it) { builtinNames.push(it[0]); });
        });
        html += '<details class="adv" style="margin:6px 0 0"><summary>内置脚本（' + builtinNames.length + ' 个，不用改）</summary>';
        builtinNames.forEach(function (n) {
            html += '<div class="card" style="margin-top:8px"><div class="card-head">' +
                '<div><div class="t">' + esc(LIB_NAMES[n]) + '</div>' +
                '<div class="s">' + esc(n) + '</div></div>' +
                '<div class="spacer"></div>' +
                '<button class="mini" data-act="run-script" data-f="' + esc(n) + '" data-builtin="1">试运行</button>' +
                '<button class="mini" data-act="edit-script" data-f="' + esc(n) + '" data-builtin="1">查看</button>' +
            '</div></div>';
        });
        html += '</details>';

        v.innerHTML = html;
    }

    function newScriptModal(tplId) {
        var tpl = tplOf(tplId || 'blank');
        var chips = SCRIPT_TPLS.map(function (t) {
            return '<button class="chip" data-act="tpl-fill" data-tpl="' + t.id + '"' +
                (t.id === tpl.id ? ' aria-pressed="true"' : '') + '>' + esc(t.title) + '</button>';
        }).join('');
        openModal('新建脚本', '文件名用英文/数字/下划线，.sh 结尾；先挑个模板再改最省事',
            '<div class="row"><label>文件名</label><div class="grow"><input type="text" id="ns-name" value="' +
                esc(tpl.name) + '" spellcheck="false"></div></div>' +
            '<div class="row"><label>显示名称</label><div class="grow"><input type="text" id="ns-label" value="' +
                esc(tpl.title) + '" placeholder="例如 打开酷安"><div class="hint">列表和选择器里显示的中文名</div></div></div>' +
            '<div class="row" style="align-items:flex-start"><label>模板</label><div class="grow"><div class="chips">' +
                chips + '</div></div></div>' +
            '<div class="row" style="align-items:flex-start"><label>内容</label><div class="grow">' +
            '<textarea id="ns-body" style="min-height:32vh;font-family:monospace" spellcheck="false">' + esc(tpl.body) + '</textarea>' +
            '<div class="hint">保存后立刻可用，不用重启。</div></div></div>' +
            '<div class="row"><div class="grow"></div><button class="mini" data-act="save-new-script">保存脚本</button></div>');
    }

    function editScriptModal(name, isBuiltin) {
        var p = isBuiltin ? builtinPath(name) : scriptPath(name);
        sh('cat ' + q(p) + ' 2>&1').then(function (r) {
            openModal((isBuiltin ? '查看内置：' : '查看 / 编辑：') + name,
                isBuiltin ? '内置脚本在模块里；要改的话保存一份到自己的脚本目录（同名会覆盖内置的）'
                          : '改完点保存，下一次触发立即生效',
                '<div class="row" style="align-items:flex-start"><label>内容</label><div class="grow">' +
                '<textarea id="es-body" style="min-height:42vh;font-family:monospace" spellcheck="false">' + esc(out(r)) + '</textarea></div></div>' +
                '<div class="row"><div class="grow"></div><button class="mini" data-act="save-edit-script" data-f="' + esc(name) + '">保存脚本</button></div>');
        });
    }

    // 试运行：用和按键触发完全一样的环境跑一次，把输出原样贴出来。
    // 「手动 sh 能跑、绑按键不灵」这种情况，看这里的报错最快定位。
    function runScriptTest(name, isBuiltin) {
        if (!S.bin) { toast('还没找到 sidekeyd，先点「重启守护进程」', true); return; }
        var p = isBuiltin ? builtinPath(name) : scriptPath(name);
        toast('正在运行 ' + name + ' …');
        sh(q(S.bin) + ' --run ' + q(p) + ' 2>&1').then(function (r) {
            uiAlert('试运行：' + name, out(r) || '（脚本没有输出）');
        });
    }

    // 把 "# 名称: xxx" 插到 shebang 下面（没有 shebang 就放第一行）
    function setScriptName(body, name) {
        if (!name) return body;
        var lines = String(body).split('\n');
        var line = '# 名称: ' + name;
        var hasShebang = lines.length && /^#!/ .test(lines[0]);
        var from = hasShebang ? 1 : 0;
        if (/^#\s*名称:/.test(lines[from] || '')) lines[from] = line;
        else lines.splice(from, 0, line);
        return lines.join('\n');
    }

    function saveScript(name, body, isNew) {
        if (!/^[a-z0-9_][a-z0-9_.-]*\.sh$/i.test(name)) { toast('文件名不合法：只能英文/数字/下划线，.sh 结尾', true); return; }
        sh('mkdir -p ' + q(scriptsDir()) + '; printf %s ' + q(b64utf8(body)) + ' | base64 -d > ' +
            q(scriptPath(name)) + ' && chmod 0755 ' + q(scriptPath(name)))
            .then(function (r) {
                if (r.errno !== 0) { uiAlert('保存失败', out(r)); return; }
                closeModal();
                toast(isNew ? '脚本已创建，在「选择动作」里就能点选' : '脚本已保存');
                return loadScripts().then(function () {
                    markDirty();
                    renderScripts();
                    renderKeys();
                });
            });
    }

    /* 简介页：作者 / 版本 / 更新链接 / 使用说明 */
    function renderAbout() {
        var ver = (S.ver || '').replace(/^v/i, '') || '1.4.0';
        var link = function (act, url, text, primary) {
            return '<button class="linkbtn' + (primary ? ' primary' : '') + '" data-act="open-link" data-url="' +
                esc(url) + '">' + esc(text) + '</button>';
        };

        var html = '<div class="hero">' +
            '<div class="hero-logo">SK</div>' +
            '<div class="hero-main">' +
                '<div class="hero-title">侧键增强<span class="hero-ver">v' + esc(ver) + '</span></div>' +
                '<div class="hero-sub">一加 / OPPO 侧键增强 · 纯 C++ 守护进程</div>' +
                '<div class="hero-chips">' +
                    '<span class="tag">作者 ' + esc(META.author) + '</span>' +
                    '<span class="tag">Magisk / KernelSU</span>' +
                '</div>' +
            '</div>' +
        '</div>';

        var nBuiltin = Object.keys(LIB_NAMES).length;
        html += '<div class="card">' +
            '<div class="card-head"><div class="t">它能做什么</div></div>' +
            '<div class="grid2">' +
                '<div class="feat"><b>音量键 / 电源键</b><span>单击到五击、长按，各配一个动作</span></div>' +
                '<div class="feat"><b>多击拦截</b><span>双击音量键只跑脚本，不加减音量</span></div>' +
                '<div class="feat"><b>三段式 / 组合键</b><span>滑块三位置、多键同按，各挂一个动作</span></div>' +
                '<div class="feat"><b>' + nBuiltin + ' 个内置动作</b><span>手电筒、截图、扫码、付款码、媒体控制…</span></div>' +
            '</div>' +
        '</div>';

        html += '<div class="card">' +
            '<div class="card-head"><div class="t">三步上手</div></div>' +
            '<ol class="steps">' +
                '<li><b>配动作</b>「按键」页点「＋手势」，挑一个动作</li>' +
                '<li><b>验证</b>点底部「保存并重启」，等 2 秒，按一下试</li>' +
                '<li><b>出问题</b>看「日志」页，或「设置 → 按键扫描」</li>' +
            '</ol>' +
        '</div>';

        html += '<div class="card">' +
            '<div class="card-head"><div class="t">版本与链接</div></div>' +
            '<div class="kv"><span>当前版本</span><b>v' + esc(ver) + '</b></div>' +
            '<div class="kv"><span>作者</span><b>' + esc(META.author) + '</b></div>' +
            '<div class="kv"><span>运行状态</span><b>' + (S.running ? '守护进程运行中' : '未运行') + '</b></div>' +
            '<div class="links">' +
                link('open', META.repo, '项目主页 / 更新下载', true) +
                link('open', META.issues, '问题反馈') +
            '</div>' +
            '<div class="hint" style="margin-top:8px">更新一般是「管理器里重新刷入新 zip → 重启」，配置和脚本会保留。</div>' +
        '</div>';

        $('view-about').innerHTML = html;
    }


    /* ------------------------------------------------------------------ */
    /* 渲染：组合键                                                        */
    /* ------------------------------------------------------------------ */

    function keyLabelOf(name) {
        for (var i = 0; i < SideModel.KEY_NAMES.length; i++)
            if (SideModel.KEY_NAMES[i].name === name) return SideModel.KEY_NAMES[i].label;
        return name;
    }

    // 组合键能选哪些键：以 `sidekeyd --keys` 探测到的真机按键为准
    // （以前直接铺 SideModel.KEY_NAMES 全表，所以会冒出这台机器根本没用的「上一曲/下一曲」）。
    // 探测不到时才退回「音量上/下 + 电源 + 配置里已有的键」。
    function chordKeys() {
        if (S.keys && S.keys.length) {
            return S.keys.map(function (k) {
                return { name: k.name, label: keyLabelOf(k.name) };
            });
        }
        var names = ['volume_up', 'volume_down', 'power'];
        ((S.model && S.model.keys) || []).forEach(function (k) {
            if (names.indexOf(k.name) < 0) names.push(k.name);
        });
        return names.map(function (n) { return { name: n, label: keyLabelOf(n) }; });
    }

    function loadKeys() {
        if (!S.bin) { S.keys = null; return Promise.resolve(); }
        return sh(q(S.bin) + ' --keys 2>/dev/null').then(function (r) {
            var list = [];
            out(r).split('\n').forEach(function (line) {
                line = line.trim();
                if (line.indexOf('KEY=') !== 0) return;
                var p = line.slice(4).split('|');
                if (!p[0]) return;
                list.push({ name: p[0], code: parseInt(p[1], 10) || 0, dev: p[2] || '' });
            });
            S.keys = list.length ? list : null;
            renderChords();
        });
    }

    /* ------------------------------------------------------------------ */
    /* 渲染：多动作序列                                                    */
    /* ------------------------------------------------------------------ */

    var STEPS = [
        { t: 'app', label: '打开应用', pick: 'app',
          cmd: function (a) { return 'monkey -p ' + a + ' -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1'; } },
        { t: 'url', label: '打开网址', arg: 'https://example.com',
          cmd: function (a) { return 'am start -a android.intent.action.VIEW -d ' + a + ' >/dev/null 2>&1'; } },
        { t: 'tap', label: '点击屏幕位置', arg: '坐标 x,y，例如 540,1200',
          cmd: function (a) {
              var p = String(a || '').split(/[^0-9]+/).filter(Boolean);
              return 'input tap ' + (p[0] || 540) + ' ' + (p[1] || p[0] || 1200) + ' >/dev/null 2>&1';
          } },
        { t: 'home', label: '回到主屏幕', cmd: function () { return 'input keyevent 3'; } },
        { t: 'back', label: '返回', cmd: function () { return 'input keyevent 4'; } },
        { t: 'recents', label: '最近任务', cmd: function () { return 'input keyevent 187'; } },
        { t: 'powermenu', label: '电源菜单（关机/重启）', cmd: function () { return 'input keyevent --longpress 26'; } },
        { t: 'volup', label: '音量 +', cmd: function () { return 'input keyevent 24'; } },
        { t: 'voldown', label: '音量 -', cmd: function () { return 'input keyevent 25'; } },
        { t: 'screenshot', label: '截图', cmd: function () { return 'input keyevent 120'; } },
        { t: 'wait', label: '等待一会儿', arg: '毫秒，例如 800',
          cmd: function (a) { return 'sleep ' + ((parseInt(a, 10) || 500) / 1000); } },
        { t: 'script', label: '运行已有脚本', pick: 'script',
          cmd: function (a) { return 'sh ' + scriptsDir() + '/' + a; } },
        { t: 'cmd', label: '自定义命令', arg: 'adb shell 里能跑的命令',
          cmd: function (a) { return a; } }
    ];

    function stepDef(t) {
        for (var i = 0; i < STEPS.length; i++) if (STEPS[i].t === t) return STEPS[i];
        return null;
    }

    function stepText(st) {
        var d = stepDef(st.t);
        if (!d) return '未知步骤 ' + st.t;
        if (d.pick === 'app') return d.label + '：' + appLabel(st.arg);   // 打开应用显示中文名，包名不上界面
        if (d.pick === 'script') return d.label + '：' + (S.scriptNames[st.arg] || st.arg);
        return d.label + (st.arg ? '：' + st.arg : '');
    }

    function seqToScript(seq) {
        var lines = ['#!/system/bin/sh', '# 名称: ' + (seq.name || '多动作序列'), '# 序列: 1',
                     '# interval: ' + (parseInt(seq.interval, 10) || 0)];
        seq.steps.forEach(function (st) { lines.push('# step: ' + st.t + '|' + (st.arg || '')); });
        lines.push('');
        var gap = (parseInt(seq.interval, 10) || 0) / 1000;
        seq.steps.forEach(function (st, i) {
            var d = stepDef(st.t);
            if (!d) return;
            var c = d.cmd(st.arg || '');
            if (!c) return;
            lines.push(c);
            if (i < seq.steps.length - 1 && gap > 0) lines.push('sleep ' + gap);
        });
        return lines.join('\n') + '\n';
    }

    function parseSeq(file, text) {
        var seq = { file: file, name: '', interval: 300, steps: [] };
        String(text || '').split('\n').forEach(function (line) {
            var m;
            if ((m = /^#\s*名称:\s*(.+)$/.exec(line))) seq.name = m[1].trim();
            else if ((m = /^#\s*interval:\s*(\d+)/.exec(line))) seq.interval = parseInt(m[1], 10);
            else if ((m = /^#\s*step:\s*([a-z]+)\|?(.*)$/.exec(line))) seq.steps.push({ t: m[1], arg: m[2] || '' });
        });
        return seq;
    }

    function seqEditor() {
        var sq = S.seq;
        var html = '<div class="card"><div class="card-head">' +
            '<div><div class="t">' + esc(sq.name || '新序列') + '</div><div class="s">' + esc(sq.file) + '</div></div>' +
            '<div class="spacer"></div>' +
            '<button class="mini" data-act="save-seq">保存</button>' +
            '<button class="mini" data-act="cancel-seq">取消</button>' +
        '</div>' +
        '<div class="row"><label>名称</label><div class="grow"><input type="text" data-seq="name" value="' +
            esc(sq.name) + '" placeholder="例如 一键打开酷安"></div></div>' +
        '<div class="row"><label>步骤间隔</label><div class="grow"><input type="number" inputmode="numeric" data-seq="interval" value="' +
            esc(sq.interval) + '"><div class="hint">毫秒，每一步执行完等这么久再走下一步（默认 300）</div></div></div>';

        html += '<div class="section-title">步骤（' + sq.steps.length + '）</div>';
        if (!sq.steps.length) {
            html += '<div class="hint" style="margin:4px 0 8px">还没有步骤。点下面「添加步骤」，从「打开应用」「主屏幕」「电源菜单」里挑。</div>';
        }
        sq.steps.forEach(function (st, i) {
            html += '<div class="seq-step">' +
                '<div class="sn">' + (i + 1) + '</div>' +
                '<div class="st">' + esc(stepText(st)) + '</div>' +
                '<button class="mini" data-act="step-up" data-i="' + i + '" aria-label="上移"' + (i === 0 ? ' disabled' : '') + '>↑</button>' +
                '<button class="mini" data-act="step-down" data-i="' + i + '" aria-label="下移"' + (i === sq.steps.length - 1 ? ' disabled' : '') + '>↓</button>' +
                '<button class="mini" data-act="step-del" data-i="' + i + '" aria-label="删除">✕</button>' +
            '</div>';
        });
        html += '<div class="row" style="margin-top:8px"><div class="grow"></div>' +
            '<button class="mini" data-act="add-step">添加步骤</button></div>' +
        '<div class="hint" style="margin-top:6px">保存后生成 <code class="inline">' + esc(sq.file) +
            '</code>，回「按键」页就能把它选成某个手势的动作。</div></div>';
        return html;
    }

    // 新建一个序列：先弹窗输名字（和新建脚本一样的体验），确认后再进编辑器。
    // bind 非空表示"保存后自动挂到这个动作上"（从选择器点进来的）
    function startNewSeq(bind) {
        openModal('新建序列', '保存后在「按键」页把任意手势选成这个序列',
            '<div class="row"><label>显示名称</label><div class="grow"><input type="text" id="ns-seq-name" value="我的多动作" placeholder="例如 一键打开酷安"><div class="hint">列表和选择器里显示的中文名</div></div></div>' +
            '<div class="modal-grid" style="margin-top:14px">' +
                '<button class="primary" data-act="create-seq">创建</button>' +
                '<button data-act="cancel-seq-create">取消</button>' +
            '</div>');
        S.seqBind = bind || null;
    }

    function createSeqFromModal() {
        var inp = $('ns-seq-name');
        var nm = (inp && inp.value ? inp.value : '我的多动作').trim() || '我的多动作';
        S.seq = {
            file: 'seq_' + Date.now().toString().slice(-6) + '.sh',
            name: nm,
            interval: 300,
            steps: []
        };
        closeModal();
        goTab('scripts');
        renderScripts();
    }

    // 多动作列表（脚本页的一个区块）；正在编辑的序列展开在下面
    function seqSection() {
        if (!S.model) return '';
        var html = '<div class="section-title">多动作</div>' +
            '<div class="card"><div class="card-head">' +
            '<div class="t">按顺序执行的一串步骤</div><div class="spacer"></div>' +
            '<button class="mini" data-act="new-seq">新建序列</button></div>';
        if (!S.seqs.length) {
            html += '<div class="hint">还没有序列。新建后一步步加：打开应用 → 等待 → 主屏幕，保存后按键/组合键/三段式都能选它。</div>';
        } else {
            S.seqs.forEach(function (n) {
                html += '<div class="row"><div class="grow"><div class="t" style="font-size:13.5px">' +
                    esc(S.scriptNames[n] || n.replace(/\.sh$/i, '')) + '</div>' +
                    '<div class="hint">' + esc(n) + '</div></div>' +
                    '<button class="mini" data-act="edit-seq" data-f="' + esc(n) + '">编辑</button>' +
                    '<button class="mini" data-act="del-seq" data-f="' + esc(n) + '">删除</button></div>';
            });
        }
        html += '</div>';

        if (S.seq) html += seqEditor();
        return html;
    }

    // 兼容旧调用：多动作已并入脚本页
    function renderSeq() { renderScripts(); }

    function openStepModal() {
        S.stepDraft = { t: 'app', arg: '' };
        openStepModalDraft();
    }

    // 步骤弹窗：类型用一行多个的网格挑，不用占满整屏的下拉；
    // 打开应用不手填包名，点「选择应用」从列表里挑
    function openStepModalDraft() {
        var d = S.stepDraft;
        var chips = STEPS.map(function (s) {
            return '<button class="chip" data-act="step-type" data-t="' + s.t + '"' +
                (s.t === d.t ? ' aria-pressed="true"' : '') + '>' + esc(s.label) + '</button>';
        }).join('');
        var def = stepDef(d.t);
        var argHtml;
        if (def && def.pick === 'app') {
            argHtml = '<div class="row" id="step-arg-row"><label>应用</label><div class="grow">' +
                '<button class="act-btn' + (d.arg ? '' : ' is-none') + '" data-act="step-pick-app">' +
                esc(d.arg ? appLabel(d.arg) : '点这里选应用') + '</button></div></div>';
        } else if (def && def.pick === 'script') {
            argHtml = '<div class="row" id="step-arg-row"><label>脚本</label><div class="grow">' +
                '<button class="act-btn' + (d.arg ? '' : ' is-none') + '" data-act="step-pick-script">' +
                esc(d.arg ? (S.scriptNames[d.arg] || d.arg) : '点这里选脚本') + '</button></div></div>';
        } else {
            var need = !!(def && def.arg);
            argHtml = '<div class="row" id="step-arg-row"' + (need ? '' : ' style="display:none"') + '>' +
                '<label>参数</label><div class="grow">' +
                '<input type="text" id="step-arg" value="' + esc(d.arg) + '" placeholder="' +
                    esc(need ? def.arg : '') + '">' +
                '<div class="hint" id="step-arg-hint">' + esc(need ? def.arg : '') + '</div></div></div>';
        }
        openModal('添加步骤', '',
            '<div class="row" style="align-items:flex-start"><label>类型</label><div class="grow">' +
                '<div class="chips">' + chips + '</div></div></div>' +
            argHtml +
            '<div class="modal-grid" style="margin-top:14px">' +
                '<button class="primary" data-act="step-confirm">确认</button>' +
                '<button data-act="step-cancel">关闭</button>' +
            '</div>');
        // 底部自带的「关闭」和上面的关闭重复，藏掉（closeModal 会恢复）
        el.modalClose.hidden = true;
    }

    function writeScriptFile(path, content) {
        return sh('mkdir -p ' + q(dirname(path)) + '; printf %s ' + q(b64utf8(content)) + ' | base64 -d > ' +
            q(path) + ' && chmod 0755 ' + q(path));
    }

    function renderAll() {
        renderKeys();
        renderScripts();
        renderGeneral();
        renderLog();
        renderAbout();
        renderStatus();
    }

    /* ------------------------------------------------------------------ */
    /* 弹窗 / 提示                                                         */
    /* ------------------------------------------------------------------ */

    var confirmResolve = null;
    var pickTarget = null;
    var pickChordIdx = -1;

    function openModal(title, sub, bodyHtml) {
        el.modalTitle.textContent = title;
        el.modalSub.textContent = sub || '';
        el.modalBody.innerHTML = bodyHtml;
        el.modalClose.hidden = false;   // 默认显示自带关闭；步骤弹窗会自己带关闭
        el.modal.hidden = false;
    }

    function closeModal() {
        el.modal.hidden = true;
        el.modalBody.innerHTML = '';
        el.modalClose.hidden = false;
        pickTarget = null;
        pickChordIdx = -1;
        appPickCb = null;
        if (confirmResolve) { var r = confirmResolve; confirmResolve = null; r(false); }
    }

    function uiConfirm(title, sub, okText) {
        return new Promise(function (resolve) {
            confirmResolve = resolve;
            openModal(title, sub,
                '<div class="modal-grid">' +
                    '<button data-confirm="1">' + esc(okText || '确定') + '</button>' +
                    '<button data-confirm="0">取消</button>' +
                '</div>');
        });
    }

    function uiAlert(title, text) {
        openModal(title, '', '<pre class="out" style="max-height:52vh">' + esc(text) + '</pre>');
    }

    var toastTimer = null;
    function toast(msg, isErr) {
        el.toast.textContent = msg;
        el.toast.className = 'toast show' + (isErr ? ' err' : '');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { el.toast.className = 'toast'; }, isErr ? 4200 : 2200);
    }

    /* ------------------------------------------------------------------ */
    /* 动作选择器                                                          */
    /* ------------------------------------------------------------------ */

    // 内置动作库：全部是 script_dir 下的 .sh 文件（统一格式，不再有内联命令）。
    // [分组, [脚本名, 中文名], ...]；命令来源：ColorOS 实测接口 +
    // 「侧键拓展 v2.6.5」「OnePlus 侧键拓展 v1.7.5」的默认命令。
    var LIB = [
        ['系统', [
            ['sys_home.sh', '主页'],
            ['sys_recents.sh', '最近任务'],
            ['sys_screen_off.sh', '息屏'],
            ['sys_screen_on.sh', '亮屏'],
            ['sys_assistant.sh', '语音助手'],
            ['sys_camera.sh', '相机'],
            ['sys_kill_app.sh', '杀掉前台应用']
        ]],
        ['ColorOS 快捷', [
            ['cos_torch.sh', '手电筒（最大功率）'],
            ['cos_torch_sys.sh', '手电筒（系统亮度·原版）'],
            ['cos_screenshot.sh', '截图'],
            ['cos_screenshot_area.sh', '区域截图'],
            ['cos_screenshot_long.sh', '长截图'],
            ['cos_record.sh', '录屏 开/关'],
            ['cos_ringer.sh', '铃声 响铃→震动→静音'],
            ['cos_dnd.sh', '免打扰 开/关'],
            ['cos_bt.sh', '蓝牙 开/关'],
            ['sys_wifi.sh', 'WiFi 开/关'],
            ['cos_nfc.sh', 'NFC 开/关'],
            ['cos_bypass.sh', '旁路充电 开/关'],
            ['cos_ocr.sh', '小布识屏'],
            ['cos_translate.sh', '屏幕翻译'],
            ['cos_flashnote.sh', '一键闪记'],
            ['cos_voicenote.sh', '小布随口记'],
            ['cos_recorder.sh', '录音 开/关'],
            ['cos_quicknote.sh', '便签速记']
        ]],
        ['微信 · 支付宝', [
            ['wx_scan.sh', '微信扫一扫'],
            ['wx_pay.sh', '微信付款码'],
            ['wx_pay_lock.sh', '微信付款码（锁屏自动解锁）'],
            ['wx_password.sh', '自动输入微信密码'],
            ['ali_scan.sh', '支付宝扫一扫'],
            ['ali_pay.sh', '支付宝付款码'],
            ['ali_trip.sh', '支付宝出行码']
        ]],
        ['媒体', [
            ['media_play.sh', '播放 / 暂停'],
            ['media_next.sh', '下一曲'],
            ['media_prev.sh', '上一曲'],
            ['media_volup.sh', '音量 +'],
            ['media_voldown.sh', '音量 -']
        ]]
    ];

    // 脚本名 -> 中文名（动作显示统一走这里）
    var LIB_NAMES = {};
    LIB.forEach(function (g) {
        g[1].forEach(function (it) { LIB_NAMES[it[0]] = it[1]; });
    });

    // 界面上显示动作的中文名；不在库里的自定义脚本显示文件名（去 .sh）
    function actionLabel(v) {
        if (v == null) return '不使用';
        var s = String(v).trim();
        if (s === '' || s === 'none' || s === '-') return '不使用';
        if (/^app:/i.test(s)) {                       // 打开应用
            var pk = s.slice(4);
            return '打开 ' + appLabel(pk);
        }
        if (/^sh:/.test(s)) return '命令：' + s.slice(3);   // 兼容老配置里的内联命令
        return LIB_NAMES[s] || S.scriptNames[s] || s.replace(/\.sh$/i, '');
    }

    // 内置动作永远可用（打包在模块里，不占用户目录）；只有"我的脚本"要看文件还在不在
    function pickable(value) {
        if (value === 'none') return true;
        if (/^app:/i.test(value)) return true;   // 打开应用：不依赖脚本文件
        if (LIB_NAMES[value]) return true;       // 内置动作：模块自带
        if (!S.scripts.length) return true;      // 拿不到脚本列表时不拦
        return S.scripts.indexOf(value) >= 0;
    }

    // 常见应用包名 -> 中文名（shell 里拿不到应用 label，用这张表兜住大多数场景）
    var APP_LABELS = {
        'com.tencent.mm': '微信',
        'com.eg.android.AlipayGphone': '支付宝',
        'com.tencent.mobileqq': 'QQ',
        'com.coolapk.market': '酷安',
        'com.ss.android.ugc.aweme': '抖音',
        'tv.danmaku.bili': '哔哩哔哩',
        'com.taobao.taobao': '淘宝',
        'com.jingdong.app.mall': '京东',
        'com.sankuai.meituan': '美团',
        'com.autonavi.minimap': '高德地图',
        'com.netease.cloudmusic': '网易云音乐',
        'com.tencent.qqmusic': 'QQ 音乐',
        'com.zhihu.android': '知乎',
        'com.xingin.xhs': '小红书',
        'com.sina.weibo': '微博',
        'com.alibaba.android.rimet': '钉钉',
        'com.tencent.wework': '企业微信',
        'org.telegram.messenger': 'Telegram',
        'com.android.settings': '设置',
        'com.oplus.camera': '相机',
        'com.coloros.gallery3d': '相册',
        'com.android.calculator2': '计算器',
        'com.android.dialer': '拨号'
    };

    function appLabel(pk) { return APP_LABELS[pk] || prettyAppName(pk); }

    // 拿不到中文名的应用：用包名最后一段有意义的东西当显示名，
    // 别把一屏 com.xxx 铺出来（包名只存配置，不上界面）
    var PKG_STOP = { com: 1, cn: 1, org: 1, net: 1, io: 1, tv: 1, me: 1, android: 1, app: 1, apps: 1,
        mobile: 1, client: 1, main: 1, activity: 1, ui: 1, project: 1, team: 1, dev: 1, launch: 1 };
    function prettyAppName(pk) {
        var segs = String(pk || '').split('.').filter(Boolean);
        for (var i = segs.length - 1; i >= 0; i--) {
            var s = segs[i];
            if (!PKG_STOP[s] && !/^\d+$/.test(s) && s.length >= 2)
                return s.charAt(0).toUpperCase() + s.slice(1);
        }
        return pk;
    }

    function loadApps() {
        if (S.apps) return Promise.resolve(S.apps);
        return sh('pm list packages -3 2>/dev/null').then(function (r) {
            var seen = {}, list = [];
            out(r).split('\n').forEach(function (l) {
                var pk = l.replace(/^\s*package:/, '').trim();
                if (!pk || pk.indexOf('.') < 0 || seen[pk]) return;
                seen[pk] = 1;
                list.push(pk);
            });
            // 常用应用即使不是「第三方」也塞进来
            Object.keys(APP_LABELS).forEach(function (pk) {
                if (!seen[pk] && ['com.android.settings', 'com.oplus.camera',
                    'com.coloros.gallery3d', 'com.android.calculator2', 'com.android.dialer'].indexOf(pk) >= 0) {
                    list.push(pk);
                }
            });
            S.apps = list;
            return list;
        });
    }

    function renderAppList(kw) {
        var box = $('app-list');
        if (!box) return;
        var k = String(kw || '').trim().toLowerCase();
        var list = (S.apps || []).filter(function (pk) {
            if (!k) return true;
            return pk.toLowerCase().indexOf(k) >= 0 || appLabel(pk).toLowerCase().indexOf(k) >= 0;
        });
        if (!list.length) { box.innerHTML = '<div class="empty">没有匹配的应用</div>'; return; }
        list.sort(function (a, b) {
            var la = APP_LABELS[a] ? 0 : 1, lb = APP_LABELS[b] ? 0 : 1;
            if (la !== lb) return la - lb;
            return appLabel(a).localeCompare(appLabel(b), 'zh');
        });
        // 一行多个的网格，只显示应用名；包名在点击时写进配置，不上界面
        box.innerHTML = '<div class="app-grid">' + list.slice(0, 300).map(function (pk) {
            return '<button class="pick-item app-cell" data-pick="app:' + esc(pk) + '">' +
                esc(appLabel(pk)) + '</button>';
        }).join('') + '</div>';
    }

    // 选应用的弹窗。带 cb 时是「给某个步骤挑应用」：点完回到原来的弹窗
    var appPickCb = null;
    function openAppPicker(cb) {
        appPickCb = cb || null;
        var html = '<div style="margin:0 0 8px"><input id="app-q" type="text" placeholder="搜索应用" spellcheck="false" autocomplete="off"></div>' +
            '<div class="pick-list" id="app-list"><div class="empty">正在读取应用列表…</div></div>';
        openModal('选择应用', '', html);
        loadApps().then(function () {
            renderAppList('');
            var inp = $('app-q');
            if (inp && inp.addEventListener) {
                inp.addEventListener('input', function () { renderAppList(inp.value); });
            }
        });
    }

    // 选脚本的弹窗（多动作「运行已有脚本」步骤用）：列出自己目录下的 .sh
    function openScriptPicker(cb) {
        var items = S.scripts.map(function (n) {
            var label = S.scriptNames[n] || n.replace(/\.sh$/i, '');
            var isSeq = S.seqs.indexOf(n) >= 0;
            return '<button class="pick-item" data-pick="script:' + esc(n) + '">' + esc(label) +
                (isSeq ? '<span class="s">多动作</span>' : '') + '</button>';
        }).join('');
        openModal('选择脚本', '',
            '<div class="pick-list" id="script-list">' +
            (items || '<div class="empty">还没有脚本。去「脚本」页新建一个，或选内置动作。</div>') +
            '</div>');
        // 复用 data-pick 流：临时接管 appPickCb，picked 值带 script: 前缀
        appPickCb = function (v) {
            if (/^script:/.test(v) && cb) cb(v.slice(7));
        };
    }

    function openPicker(bind, cap) {
        pickTarget = bind;
        var html = '<div class="pick-list">';

        // 「不使用」固定置顶
        html += '<button class="pick-item none" data-pick="none"><b>不使用</b></button>';
        html += '<button class="pick-item" data-pick="__app__"><b>打开应用</b></button>';
        html += '<button class="pick-item" data-pick="__seq__"><b>新建多动作</b></button>';

        LIB.forEach(function (group) {
            var items = group[1].filter(function (it) { return pickable(it[0]); });
            if (!items.length) return;
            html += '<div class="section-title">' + group[0] + '</div>' +
                items.map(function (it) {
                    return '<button class="pick-item" data-pick="' + esc(it[0]) + '">' + esc(it[1]) + '</button>';
                }).join('');
        });
        // 剩下的脚本（自己加的，或者上面没归类的）
        var used = {};
        LIB.forEach(function (g) {
            g[1].forEach(function (it) { used[it[0]] = true; });
        });
        var mine = S.scripts.filter(function (n) { return !used[n] && n.charAt(0) !== '_'; });
        if (mine.length) {
            html += '<div class="section-title">我的脚本 / 多动作</div>' +
                mine.map(function (n) {
                    var label = S.scriptNames[n] || n.replace(/\.sh$/i, '');
                    var isSeq = S.seqs.indexOf(n) >= 0;
                    return '<button class="pick-item" data-pick="' + esc(n) + '">' + esc(label) +
                        (isSeq ? '<span class="s">多动作</span>' : '') + '</button>';
                }).join('');
        }
        html += '</div>';
        openModal('选择动作', cap || '', html);
    }

    function applyPick(value) {
        if (!pickTarget) return;
        if (value === '__app__') {
            // 进应用列表前把目标字段记住：closeModal 会清 pickTarget，
            // 不记住的话选完应用就没地方落了（表现为"选了应用保存不上"）
            var back = pickTarget;
            closeModal();
            setTimeout(function () { openAppPicker(null); pickTarget = back; }, 60);
            return;
        }
        if (value === '__seq__') {
            // 和 __app__ 一样：closeModal 会清 pickTarget，先记住
            var backSeq = pickTarget;
            closeModal();
            setTimeout(function () { startNewSeq(backSeq); }, 60);
            return;
        }
        setPath(pickTarget, value);
        renderKeys();
        closeModal();
    }

    /* ------------------------------------------------------------------ */
    /* 保存                                                                */
    /* ------------------------------------------------------------------ */

    function validate() {
        var errs = [];
        var g = S.model.general;
        if (!(g.tap_window_ms >= 60 && g.tap_window_ms <= 1000)) errs.push('连击窗口要在 60–1000 毫秒之间');
        if (!(g.long_press_ms >= 100 && g.long_press_ms <= 3000)) errs.push('长按阈值要在 100–3000 毫秒之间');
        if (!(g.max_taps >= 1 && g.max_taps <= 5)) errs.push('最多次数只能是 1–5');
        var names = {};
        S.model.keys.forEach(function (k) {
            if (!k.name) errs.push('有按键段没有名字');
            if (names[k.name]) errs.push('按键 ' + k.name + ' 重复');
            names[k.name] = true;
            ['tap_window_ms', 'long_press_ms', 'max_taps'].forEach(function (f) {
                if (k[f] !== '' && k[f] != null && isNaN(parseInt(k[f], 10))) errs.push(k.label + ' 的 ' + f + ' 不是数字');
            });
        });
        if (S.model.slider.poll_ms && (S.model.slider.poll_ms < 50 || S.model.slider.poll_ms > 5000)) {
            errs.push('滑块轮询间隔要在 50–5000 毫秒之间');
        }
        return errs;
    }

    function doSave(restart) {
        if (S.busy) return;
        if (!S.model) { toast('没有可保存的配置', true); return; }
        var errs = validate();
        if (errs.length) { uiAlert('配置有问题', errs.join('\n')); return; }

        var proceed = Promise.resolve(true);
        var needGate = S.model.keys.some(function (k) {
            if (!k.gate_multi) return false;
            if (k.name === 'power' && !k.intercept) return false;
            return ['double', 'triple', 'four', 'five'].some(function (f) {
                return k[f] && k[f] !== 'none';
            });
        });
        if (needGate && !S.uinput) {
            proceed = uiConfirm('无法拦截原功能',
                '系统里没有可用的 /dev/uinput，模块没法独占按键设备。' +
                '保存后双击仍会同时加减音量。仍要继续？', '继续保存');
        }

        proceed.then(function (ok) {
            if (!ok) return;
            S.busy = true;
            el.btnSaveRun.disabled = true;
            el.btnSave.disabled = true;
            el.btnSave.textContent = '保存中…';

            var conf = IniConf.parse(S.text);
            SideModel.apply(conf, S.model);
            var text = IniConf.serialize(conf);
            var tmp = PATHS.cfg + '.new';

            writeFile(tmp, text).then(function (w) {
                if (w.errno !== 0) throw new Error('写临时文件失败: ' + out(w));
                if (!S.bin) return { errno: 0, stdout: 'SKIP' };
                return sh(q(S.bin) + ' -c ' + q(tmp) + ' --check 2>&1');
            }).then(function (chk) {
                if (chk.errno !== 0) {
                    throw new Error('配置校验没通过：\n' + out(chk));
                }
                return sh('cp -f ' + q(PATHS.cfg) + ' ' + q(PATHS.cfg + '.bak') + ' 2>/dev/null; mv -f ' + q(tmp) + ' ' + q(PATHS.cfg) + ' && chmod 0644 ' + q(PATHS.cfg));
            }).then(function (mv) {
                if (mv.errno !== 0) throw new Error('写入配置失败: ' + out(mv));
                S.text = text;
                S.dirty = false;
                document.body.classList.remove('dirty');
                if (!restart) {
                    toast('已保存，重启守护进程后生效');
                    return null;
                }
                return sh('sh ' + q(PATHS.mod + '/action.sh') + ' 2>&1');
            }).then(function (r) {
                if (!r) return;
                return refreshStatus().then(function () {
                    if (S.running) toast('已保存并重启');
                    else { toast('保存了，但守护进程没起来，看日志', true); uiAlert('启动失败', out(r)); }
                });
            }).catch(function (e) {
                uiAlert('保存失败', e.message || String(e));
            }).then(function () {
                S.busy = false;
                el.btnSaveRun.disabled = false;
                el.btnSave.disabled = false;
                el.btnSave.textContent = '保存';
            });
        });
    }

    /* ------------------------------------------------------------------ */
    /* 工具动作                                                            */
    /* ------------------------------------------------------------------ */

    function runMonitor() {
        var pre = $('out-monitor');
        pre.hidden = false;
        pre.innerHTML = '<span class="spinner"></span>监听 6 秒，现在按几下音量键/拨一下滑块…';
        if (!S.bin) { pre.textContent = '找不到 sidekeyd'; return; }
        sh(q(S.bin) + ' --monitor -s 6 2>&1').then(function (r) {
            pre.textContent = out(r) || '(没有捕获到事件，检查设备是否被独占)';
        });
    }

    function runCheck() {
        var pre = $('out-check');
        pre.hidden = false;
        pre.innerHTML = '<span class="spinner"></span>校验中…';
        if (!S.bin) { pre.textContent = '找不到 sidekeyd'; return; }
        sh(q(S.bin) + ' -c ' + q(PATHS.cfg) + ' --check 2>&1').then(function (r) {
            pre.textContent = (r.errno === 0 ? '校验通过 ✓\n\n' : '校验失败 ✗\n\n') + out(r);
        });
    }

    function loadLog() {
        var pre = $('out-log');
        if (!pre) return;
        var g = (S.model && S.model.general) || {};
        if (!g.log_enabled) {
            pre.textContent = '日志总开关是关闭的，不会有新内容。';
            return;
        }
        pre.textContent = '读取中…';
        sh('tail -n 150 ' + q(logFile()) + ' 2>/dev/null').then(function (r) {
            pre.textContent = out(r) || '(日志为空：可能还没触发过动作，或者等级设得太高)';
            pre.scrollTop = pre.scrollHeight;
        });
    }

    function loadDaemonOut() {
        var pre = $('out-daemon');
        if (!pre) return;
        pre.textContent = '读取中…';
        sh('tail -n 60 ' + q(daemonOut()) + ' 2>/dev/null').then(function (r) {
            pre.textContent = out(r) || '(没有启动输出：要么 log_daemon_out 关着，要么还没重启过)';
        });
    }

    function restartDaemon() {
        toast('正在重启…');
        sh('sh ' + q(PATHS.mod + '/action.sh') + ' 2>&1').then(function (r) {
            return refreshStatus().then(function () {
                if (S.running) toast('已重启');
                else { toast('启动失败', true); uiAlert('启动失败', out(r)); }
            });
        });
    }

    /* ------------------------------------------------------------------ */
    /* 事件                                                                */
    /* ------------------------------------------------------------------ */

    function goTab(name, btn) {
        document.querySelectorAll('.tab').forEach(function (b) {
            b.classList.toggle('active', btn ? b === btn : (b.getAttribute && b.getAttribute('data-tab') === name));
        });
        document.querySelectorAll('.view').forEach(function (v) { v.classList.remove('active'); });
        var view = $('view-' + name);
        if (view) view.classList.add('active');
        if (name === 'log') { renderLog(); loadLog(); loadDaemonOut(); }
        if (name === 'scripts') renderScripts();
        if (name === 'general') renderGeneral();
        window.scrollTo && window.scrollTo(0, 0);
    }

    function onClick(e) {
        var t = e.target.closest ? e.target.closest('[data-tab],[data-go],[data-act],[data-toggle],[data-pick],[data-confirm]') : null;
        if (!t) return;

        if (t.hasAttribute('data-tab')) {
            goTab(t.getAttribute('data-tab'), t);
            return;
        }

        if (t.hasAttribute('data-go')) {   // 页面内的"去某页设置"跳转
            goTab(t.getAttribute('data-go'));
            return;
        }

        if (t.hasAttribute('data-confirm')) {
            var val = t.getAttribute('data-confirm') === '1';
            var r = confirmResolve;
            confirmResolve = null;
            el.modal.hidden = true;
            el.modalBody.innerHTML = '';
            if (r) r(val);
            return;
        }

        if (t.hasAttribute('data-pick')) {
            var pv = t.getAttribute('data-pick');
            // 应用选择器带着回调：这次选择是给「添加步骤」用的，点完回步骤弹窗
            if (appPickCb) {
                var acb = appPickCb;
                appPickCb = null;
                closeModal();
                acb(pv);
                return;
            }
            if (pickChordIdx >= 0 && S.model && S.model.chords[pickChordIdx]) {
                S.model.chords[pickChordIdx].action = pv;
                pickChordIdx = -1;
                markDirty();
                closeModal();
                renderChords();
                return;
            }
            applyPick(pv);
            return;
        }

        if (t.hasAttribute('data-toggle')) {
            var on = t.getAttribute('aria-checked') === 'true';
            t.setAttribute('aria-checked', on ? 'false' : 'true');
            setPath(t.getAttribute('data-toggle'), !on);
            var tg = t.getAttribute('data-toggle');
            if (tg === 'slider.block_original') renderSlider();
            if (tg.indexOf('keys.') === 0 && (tg.indexOf('gate_multi') > 0 || tg.indexOf('intercept') > 0)) renderKeys();
            if (tg.indexOf('chords.') === 0) renderChords();
            if (tg.indexOf('general.log_') === 0) { renderLog(); renderGeneral(); }
            return;
        }

        var act = t.getAttribute('data-act');

        /* ---- 音量键方向：一个开关 auto ↔ on ---- */
        if (act === 'vol-swap') {
            var sw = t.getAttribute('aria-checked') === 'true';
            t.setAttribute('aria-checked', sw ? 'false' : 'true');
            S.model.general.volume_swap = sw ? 'auto' : 'on';
            markDirty();
            return;
        }

        /* ---- 锁屏密码配置（写 wx_password.conf，立即生效） ---- */
        if (act === 'pwd-chain') {
            var pc = t.getAttribute('aria-checked') === 'true';
            t.setAttribute('aria-checked', pc ? 'false' : 'true');
            return;
        }
        if (act === 'pwd-save') {
            var dinp = $('wx-digits');
            var dig = ((dinp && dinp.value) || '').replace(/\D/g, '');
            var ch = $('wx-chain').getAttribute('aria-checked') === 'true';
            // 加密保存：调 wx_password_set.sh，密码明文只出现在命令行参数里
            //（瞬间传给 root 脚本），落盘一律是密文 enc=，密钥仅 root 可读。
            sh('sh ' + q(PATHS.mod + '/scripts/wx_password_set.sh') + ' ' + q(dig || '--clear') + ' ' + (ch ? '1' : '0'))
                .then(function (r) {
                    var o = out(r) || '';
                    if (/^OK:(\d+)/m.test(o)) {
                        if (dinp) {
                            dinp.value = '';
                            dinp.placeholder = '已加密保存（' + parseInt(RegExp.$1, 10) + ' 位）。输入新密码可覆盖';
                        }
                        toast(ch ? '密码已加密保存（' + RegExp.$1 + ' 位），仅存本机' : '已保存：未设置密码数字，自动输密码不会动作');
                    } else {
                        toast('保存失败：' + (o || '脚本执行出错'));
                    }
                });
            return;
        }

        /* ---- 组合键 ---- */
        /* ---- 日志开关 ---- */
        if (act === 'log-debug-on') {
            var lg = S.model.general;
            lg.log_enabled = true;
            lg.log_level = 3;
            lg.log_script = true;
            lg.log_daemon_out = true;
            markDirty();
            renderLog();
            renderGeneral();
            toast('已切到调试模式，点底部「保存并重启」生效');
            return;
        }
        if (act === 'log-off') {
            S.model.general.log_enabled = false;
            markDirty();
            renderLog();
            renderGeneral();
            toast('已关闭日志，保存并重启后不再写任何日志');
            return;
        }

        if (act === 'add-chord') {
            S.model.chords = S.model.chords || [];
            S.model.chords.push({ name: '', keys: [], action: 'none', window_ms: 250, ordered: false, block: false });
            markDirty();
            renderChords();
            return;
        }
        if (act === 'del-chord') {
            var dci = parseInt(t.getAttribute('data-i'), 10);
            S.model.chords.splice(dci, 1);
            markDirty();
            renderChords();
            return;
        }
        if (act === 'chord-key') {
            var cki = parseInt(t.getAttribute('data-i'), 10);
            var ckk = t.getAttribute('data-k');
            var ch = S.model.chords[cki];
            if (!ch) return;
            var at = ch.keys.indexOf(ckk);
            if (at >= 0) ch.keys.splice(at, 1); else ch.keys.push(ckk);
            ch.name = ch.keys.join('+');          // 段名跟着按键走，改键就换一段
            t.setAttribute('aria-pressed', at >= 0 ? 'false' : 'true');
            markDirty();
            renderChords();
            return;
        }
        if (act === 'pick-chord') {
            pickChordIdx = parseInt(t.getAttribute('data-i'), 10);
            openPicker(null, t.getAttribute('data-cap'));
            return;
        }
        if (act === 'clear-chord') {
            S.model.chords[parseInt(t.getAttribute('data-i'), 10)].action = 'none';
            markDirty();
            renderChords();
            return;
        }

        /* ---- 多动作序列 ---- */
        if (act === 'new-seq') {
            startNewSeq(null);
            return;
        }
        if (act === 'create-seq') { createSeqFromModal(); return; }
        if (act === 'cancel-seq-create') { closeModal(); return; }
        if (act === 'edit-seq') {
            var sf = t.getAttribute('data-f');
            sh('cat ' + q(scriptPath(sf)) + ' 2>/dev/null').then(function (r) {
                S.seq = parseSeq(sf, out(r));
                renderSeq();
            });
            return;
        }
        if (act === 'del-seq') {
            var df = t.getAttribute('data-f');
            uiConfirm('删除序列', '会删掉文件 ' + df + '，引用它的按键动作会失效。', '删除').then(function (ok) {
                if (!ok) return;
                sh('rm -f ' + q(scriptPath(df))).then(function () {
                    if (S.seq && S.seq.file === df) S.seq = null;
                    loadScripts().then(function () { renderSeq(); });
                });
            });
            return;
        }
        if (act === 'save-seq') {
            if (!S.seq) return;
            if (!S.seq.steps.length) { toast('先加一个步骤再保存', true); return; }
            var body = seqToScript(S.seq);
            var path = scriptPath(S.seq.file);
            var trimFile = S.seq.file;
            var bind = S.seqBind;
            writeScriptFile(path, body).then(function (r) {
                if (r.errno !== 0) { uiAlert('保存失败', out(r)); return; }
                S.seq = null;
                S.seqBind = null;
                // 如果是从「选择动作」里点进来的，保存后自动挂到那个手势上
                if (bind && S.model) {
                    setPath(bind, trimFile);
                    toast('已保存并设为该动作');
                } else {
                    toast('序列已保存，可以在按键/组合键里选它了');
                }
                loadScripts().then(function () {
                    renderScripts(); renderKeys();
                });
            });
            return;
        }
        if (act === 'cancel-seq') {
            S.seq = null;
            renderSeq();
            return;
        }
        if (act === 'add-step') { openStepModal(); return; }
        if (act === 'step-cancel') { S.stepDraft = null; closeModal(); return; }
        if (act === 'step-type') {
            if (!S.stepDraft) S.stepDraft = { t: 'app', arg: '' };
            S.stepDraft.t = t.getAttribute('data-t');
            S.stepDraft.arg = '';
            openStepModalDraft();
            return;
        }
        if (act === 'step-pick-app') {
            openAppPicker(function (v) {
                if (/^app:/.test(v)) {
                    if (!S.stepDraft) S.stepDraft = { t: 'app', arg: '' };
                    S.stepDraft.arg = v.slice(4);
                }
                openStepModalDraft();
            });
            return;
        }
        if (act === 'step-pick-script') {
            openScriptPicker(function (name) {
                if (!S.stepDraft) S.stepDraft = { t: 'script', arg: '' };
                S.stepDraft.arg = name;
                openStepModalDraft();
            });
            return;
        }
        if (act === 'step-confirm') {
            var st = S.stepDraft || { t: 'app', arg: '' };
            var def = stepDef(st.t);
            var sArg = (st.arg || '').trim();
            // 参数输入框以界面上最新的值为准（防止 input 事件没触发）
            var inp = $('step-arg');
            if (!def.pick && inp && inp.value != null) sArg = String(inp.value).trim();
            if (def.pick === 'app' && !sArg) { toast('先选一个应用', true); return; }
            if (def.pick === 'script' && !sArg) { toast('先选一个脚本', true); return; }
            if (def.arg && !sArg) { toast('这个步骤要填参数', true); return; }
            S.seq.steps.push({ t: st.t, arg: sArg });
            S.stepDraft = null;
            closeModal();
            renderSeq();
            return;
        }
        if (act === 'step-up' || act === 'step-down' || act === 'step-del') {
            var si = parseInt(t.getAttribute('data-i'), 10);
            if (!S.seq) return;
            if (act === 'step-del') S.seq.steps.splice(si, 1);
            else {
                var to = act === 'step-up' ? si - 1 : si + 1;
                if (to < 0 || to >= S.seq.steps.length) return;
                var tmp = S.seq.steps[si];
                S.seq.steps[si] = S.seq.steps[to];
                S.seq.steps[to] = tmp;
            }
            renderSeq();
            return;
        }

        if (act === 'pick') {
            openPicker(t.getAttribute('data-bind'), t.getAttribute('data-cap'));
        } else if (act === 'clear-act') {
            var cb = t.getAttribute('data-bind');
            setPath(cb, 'none');
            renderKeys();
        } else if (act === 'listen-add') {
            listenAddKeys();
        } else if (act === 'add-key') {
            var sel = $('add-key-sel');
            if (!sel) return;
            var name = (sel.value || '').trim();
            if (!name) { toast('先选一个按键名', true); return; }
            if (S.model.keys.some(function (k) { return k.name === name; })) { toast('这个键已经加过了', true); return; }
            S.model.keys.push(newKey(name));
            markDirty();
            renderKeys();
            toast('已添加 ' + SideModel.labelOf(name) + '，记得配动作后保存');
        } else if (act === 'new-script') {
            newScriptModal('blank');
        } else if (act === 'tpl-script') {
            newScriptModal('camera');
        } else if (act === 'tpl-fill') {
            var tp = tplOf(t.getAttribute('data-tpl'));
            var nmEl = $('ns-name'), bdEl = $('ns-body');
            if (nmEl) nmEl.value = tp.name;
            if (bdEl) bdEl.value = tp.body;
            Array.prototype.forEach.call(
                document.querySelectorAll('[data-act="tpl-fill"]'),
                function (b) { b.setAttribute('aria-pressed', b === t ? 'true' : 'false'); });
        } else if (act === 'open-link') {
            var url = t.getAttribute('data-url') || '';
            if (!url) return;
            sh('am start -a android.intent.action.VIEW -d ' + q(url) + ' >/dev/null 2>&1').then(function (r) {
                if (r.errno !== 0) toast('打不开浏览器：' + url, true);
            });
        } else if (act === 'save-new-script') {
            var nn = ($('ns-name') && $('ns-name').value || '').trim();
            if (!/\.sh$/i.test(nn)) nn += '.sh';
            var nl = ($('ns-label') && $('ns-label').value || '').trim();
            saveScript(nn, setScriptName($('ns-body').value, nl), true);
        } else if (act === 'edit-script') {
            editScriptModal(t.getAttribute('data-f'), t.getAttribute('data-builtin') === '1');
        } else if (act === 'run-script') {
            runScriptTest(t.getAttribute('data-f'), t.getAttribute('data-builtin') === '1');
        } else if (act === 'save-edit-script') {
            saveScript(t.getAttribute('data-f'), $('es-body').value, false);
        } else if (act === 'del-script') {
            var sf = t.getAttribute('data-f');
            uiConfirm('删除脚本', '将删除 ' + sf + '，引用它的动作会失效', '删除').then(function (ok) {
                if (!ok) return;
                sh('rm -f ' + q(scriptPath(sf))).then(function () {
                    toast('已删除');
                    return loadScripts().then(function () { renderScripts(); renderKeys(); });
                });
            });
        } else if (act === 'del-key') {
            var i = parseInt(t.getAttribute('data-i'), 10);
            uiConfirm('删除按键段', '将移除 [key ' + S.model.keys[i].name + '] 及其全部动作', '删除').then(function (ok) {
                if (!ok) return;
                S.model.keys.splice(i, 1);
                markDirty();
                renderKeys();
            });
        } else if (act === 'reload-dev') {
            S.devLoaded = false;
            renderKeys();
            loadDeviceStatus().then(function () { toast('已重新识别'); });
        } else if (act === 'scan-keys') {
            toast('正在扫描按键…');
            S.devLoaded = false;
            loadDeviceStatus()
                .then(function () { return loadKeys(); })
                .then(function () { renderGeneral(); toast('扫描完成'); });
        } else if (act === 'monitor') runMonitor();
        else if (act === 'check') runCheck();
        else if (act === 'restart') restartDaemon();
        else if (act === 'torch-repair') {
            toast('正在修复手电筒…');
            sh('SIDEKEY_DATA=' + q(PATHS.data) + ' TORCH_REPAIR=1 sh ' + q(builtinPath('cos_torch.sh')) + ' 2>&1')
                .then(function (r) {
                    if (r.errno !== 0) { toast('修复失败', true); uiAlert('修复失败', out(r)); return; }
                    toast('修复完成，10 秒后手电筒即可用');
                });
        }
        else if (act === 'log-refresh') loadLog();
        else if (act === 'out-refresh') loadDaemonOut();
        else if (act === 'clearlog') {
            sh(': > ' + q(logFile()) + '; : > ' + q(daemonOut())).then(function () { loadLog(); loadDaemonOut(); toast('日志已清空'); });
        } else if (act === 'defaults') {
            uiConfirm('恢复默认配置', '会用模块模板覆盖当前配置，你的修改全部丢失', '覆盖').then(function (ok) {
                if (!ok) return;
                sh('cp -f ' + q(PATHS.mod + '/config/sidekey.conf') + ' ' + q(PATHS.cfg) + ' && chmod 0644 ' + q(PATHS.cfg))
                    .then(function (r) {
                        if (r.errno !== 0) { toast('恢复失败', true); uiAlert('恢复失败', out(r)); return; }
                        toast('已恢复默认');
                        return loadConfig().then(restartDaemon);
                    });
            });
        }
    }

    function onInput(e) {
        var t = e.target;
        // 序列编辑器与步骤类型下拉没有 data-bind，必须先处理，否则会被下面的拦掉
        if (t.hasAttribute && t.hasAttribute('data-seq') && S.seq) {
            var sk = t.getAttribute('data-seq');
            S.seq[sk] = (sk === 'interval') ? (parseInt(t.value, 10) || 0) : t.value;
            return;
        }
        if (t.id === 'step-arg' && S.stepDraft) {
            S.stepDraft.arg = t.value;
            return;
        }
        var bind = t.getAttribute && t.getAttribute('data-bind');
        if (!bind) return;
        var v = t.value;
        // 下拉框里的纯数字（次数/等级）转成 number，其余保持字符串
        if (t.tagName === 'SELECT' && /^\d+$/.test(v)) v = parseInt(v, 10);
        setPath(bind, v);
    }

    /* ------------------------------------------------------------------ */
    /* 启动                                                                */
    /* ------------------------------------------------------------------ */

    function paintChrome() {
        el.pill = $('status-pill');
        el.pillText = $('status-pill-text');
        el.statusText = $('status-text');
        el.modal = $('modal');
        el.modalTitle = $('modal-title');
        el.modalSub = $('modal-sub');
        el.modalBody = $('modal-body');
        el.modalClose = $('modal-close');
        el.toast = $('toast');
        el.btnSave = $('btn-save');
        el.btnSaveRun = $('btn-save-run');
    }

    function bind() {
        document.addEventListener('click', onClick);
        document.addEventListener('input', onInput);
        document.addEventListener('change', onInput);
        $('modal-close').addEventListener('click', closeModal);
        el.modal.addEventListener('click', function (e) { if (e.target === el.modal) closeModal(); });
        $('btn-save').addEventListener('click', function () { doSave(false); });
        $('btn-save-run').addEventListener('click', function () { doSave(true); });
        $('btn-reload').addEventListener('click', function () {
            if (S.dirty) {
                uiConfirm('放弃修改', '有未保存的改动，确定重新读取配置文件？', '放弃').then(function (ok) {
                    if (ok) loadConfig();
                });
            } else {
                loadConfig();
            }
        });
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden && S.api) refreshStatus();
        });
    }

    function boot() {
        paintChrome();
        bind();
        S.api = ksuApi();
        renderTools();
        renderLog();
        if (!S.api) {
            renderStatus();
            $('view-keys').innerHTML = '<div class="note danger"><div>没有拿到 root shell 接口。' +
                '<br>请从 <b>KernelSU 管理器 → 模块 → 侧键增强 → 打开 WebUI</b> 进入本页面。' +
                '<br>用普通浏览器打开时只能看界面，读不到配置。</div></div>';
            return;
        }
        refreshStatus()
            .then(loadScripts)
            .then(loadConfig)
            .then(function () { return loadDeviceStatus(); })
            .then(function () {
                // 状态栏拉第二次，拿到 VER 后填充副标题
                return refreshStatus();
            });
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
})();

/* iniconf.js - 行级 ini 补丁器
 *
 * 设计目标：改配置时**不丢用户的注释、未知字段和排版**。
 * 做法是把原文切成 [raw] / [block] 两种块，值改写只作用于命中的那一行，
 * 新键插到该段最后一个非空行之后，删段落就整块移除。
 *
 * 同时兼容浏览器（globalThis.IniConf）和 node（供 tests/test_iniconf.js 直接 eval）。
 */
var IniConf = (function () {
    'use strict';

    function lc(s) { return String(s == null ? '' : s).toLowerCase(); }
    function trim(s) { return String(s == null ? '' : s).replace(/^[\s]+|[\s]+$/g, ''); }

    function unquote(v) {
        var t = trim(v);
        if (t.length >= 2 && t.charAt(0) === '"' && t.charAt(t.length - 1) === '"') return t.slice(1, -1);
        return t;
    }

    // 段头解析：支持 [general] / [key volume_up] / [key "volume up"]
    function parseHeader(text) {
        var m = /^\[([^\]]*)\]/.exec(trim(text));
        if (!m) return null;
        var body = trim(m[1]);
        var sp = body.search(/[\s\t]/);
        var name, arg = '', quoted = false;
        if (sp < 0) {
            name = lc(body);
        } else {
            name = lc(body.slice(0, sp));
            arg = trim(body.slice(sp));
            if (arg.length >= 2 && arg.charAt(0) === '"' && arg.charAt(arg.length - 1) === '"') {
                arg = arg.slice(1, -1);
                quoted = true;
            }
        }
        return { name: name, arg: arg, quoted: quoted };
    }

    function parse(text) {
        var src = String(text == null ? '' : text).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        var lines = src.split('\n');
        var chunks = [];
        var raw = [];
        var cur = null;

        for (var i = 0; i < lines.length; i++) {
            var line = lines[i];
            var t = trim(line);
            var h = (t.charAt(0) === '[') ? parseHeader(t) : null;
            if (h) {
                if (raw.length) { chunks.push({ type: 'raw', lines: raw }); raw = []; }
                cur = { type: 'block', name: h.name, arg: h.arg, quoted: h.quoted, body: [], entries: [], dead: false };
                chunks.push(cur);
                continue;
            }
            if (cur) {
                cur.body.push(line);
                if (t && t.charAt(0) !== '#' && t.charAt(0) !== ';') {
                    var eq = t.indexOf('=');
                    if (eq > 0) cur.entries.push({ key: lc(trim(t.slice(0, eq))), idx: cur.body.length - 1 });
                }
            } else {
                raw.push(line);
            }
        }
        if (raw.length) chunks.push({ type: 'raw', lines: raw });
        return { chunks: chunks };
    }

    function blocks(conf, name) {
        var out = [];
        var want = lc(name);
        for (var i = 0; i < conf.chunks.length; i++) {
            var c = conf.chunks[i];
            if (c.type === 'block' && !c.dead && c.name === want) out.push(c);
        }
        return out;
    }

    function block(conf, name, arg) {
        var list = blocks(conf, name);
        var want = arg == null ? '' : String(arg);
        for (var i = 0; i < list.length; i++) if (list[i].arg === want) return list[i];
        return null;
    }

    function entryOf(blk, key) {
        var k = lc(trim(key));
        for (var i = 0; i < blk.entries.length; i++) if (blk.entries[i].key === k) return blk.entries[i];
        return null;
    }

    function get(conf, name, arg, key) {
        var blk = block(conf, name, arg);
        if (!blk) return null;
        var e = entryOf(blk, key);
        if (!e) return null;
        var line = blk.body[e.idx];
        if (line == null) return null;
        var eq = line.indexOf('=');
        if (eq < 0) return null;
        return unquote(line.slice(eq + 1));
    }

    function insertEntry(blk, key, value) {
        var text = lc(trim(key)) + ' = ' + value;
        // 插到该段最后一条"真键值"之后：这样不会被甩到段尾注释的下方
        var at = 0;
        for (var i = 0; i < blk.entries.length; i++) {
            if (blk.entries[i].idx >= at && blk.body[blk.entries[i].idx] !== null) at = blk.entries[i].idx + 1;
        }
        blk.body.splice(at, 0, text);
        for (var j = 0; j < blk.entries.length; j++) if (blk.entries[j].idx >= at) blk.entries[j].idx++;
        blk.entries.push({ key: lc(trim(key)), idx: at });
    }

    // value === null 表示删除这一行；键不存在时什么都不做
    function set(conf, name, arg, key, value) {
        var blk = block(conf, name, arg);
        if (!blk) {
            if (value === null || value === undefined) return null;
            blk = addBlock(conf, name, arg);
        }
        var e = entryOf(blk, key);
        if (value === null || value === undefined) {
            if (e) blk.body[e.idx] = null;
            return blk;
        }
        var text = lc(trim(key)) + ' = ' + String(value);
        if (e) blk.body[e.idx] = text;
        else insertEntry(blk, key, String(value));
        return blk;
    }

    function addBlock(conf, name, arg) {
        var a = arg == null ? '' : String(arg);
        var blk = { type: 'block', name: lc(name), arg: a, quoted: /[\s\t]/.test(a), body: [], entries: [], dead: false };
        conf.chunks.push({ type: 'raw', lines: [''] });
        conf.chunks.push(blk);
        blk.body.push('');
        return blk;
    }

    // 清掉紧挨着段头的注释/空行（多半是这个小节的说明），但不动整块 banner。
    // 上一块可能是 raw（文件里第一段之前）也可能是普通块（段与段之间的注释会被
    // 解析器归到上一段的 body 里），两种情况都要处理，否则删掉一个按键段会留下孤儿注释。
    function stripLeadingComments(lines) {
        var hadBlank = false;
        while (lines.length && trim(lines[lines.length - 1]) === '') {
            lines.pop();
            hadBlank = true;
        }
        if (hadBlank) return;
        var n = 0;
        while (lines.length && n < 4) {
            var t = trim(lines[lines.length - 1]);
            if (t.charAt(0) !== '#' && t.charAt(0) !== ';') break;
            lines.pop();
            n++;
        }
    }

    function removeBlock(conf, name, arg) {
        var blk = block(conf, name, arg);
        if (!blk) return false;
        var idx = conf.chunks.indexOf(blk);
        var prev = conf.chunks[idx - 1];
        if (prev && prev.type === 'raw') stripLeadingComments(prev.lines);
        else if (prev && prev.type === 'block' && !prev.dead) stripLeadingComments(prev.body);
        blk.dead = true;
        return true;
    }

    function fmtArg(blk) {
        if (!blk.arg) return '';
        if (blk.quoted || /[\s\t]/.test(blk.arg)) return ' "' + blk.arg + '"';
        return ' ' + blk.arg;
    }

    function serialize(conf) {
        var out = [];
        for (var i = 0; i < conf.chunks.length; i++) {
            var c = conf.chunks[i];
            if (c.type === 'raw') {
                for (var r = 0; r < c.lines.length; r++) out.push(c.lines[r]);
                continue;
            }
            if (c.dead) continue;
            out.push('[' + c.name + fmtArg(c) + ']');
            for (var b = 0; b < c.body.length; b++) {
                if (c.body[b] !== null) out.push(c.body[b]);
            }
        }
        // 去掉文件末尾多余空行，只留一个换行
        while (out.length && trim(out[out.length - 1]) === '') out.pop();
        return out.join('\n') + '\n';
    }

    return {
        parse: parse,
        serialize: serialize,
        blocks: blocks,
        block: block,
        get: get,
        set: set,
        addBlock: addBlock,
        removeBlock: removeBlock,
        trim: trim
    };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = IniConf;

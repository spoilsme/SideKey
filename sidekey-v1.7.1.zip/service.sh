#!/system/bin/sh
# late_start service：等系统起来后拉起守护进程
#
# 数据目录放在用户可见的 Android 目录里（/storage/emulated/0/Android/sidekey），
# 用文件管理器就能改脚本和配置。注意该分区是 noexec 挂载，脚本必须用 `sh 路径` 执行。
MODDIR=${0%/*}
NEW_DIR=/storage/emulated/0/Android/sidekey
OLD_DIR=/data/adb/sidekey

# 从配置里读一个布尔项（读不到就用默认值），给下面的日志开关用
conf_bool() {   # $1=配置路径 $2=键名 $3=默认值(0/1)
    _v=$(sed -n "s/^[[:space:]]*$2[[:space:]]*=[[:space:]]*//p" "$1" 2>/dev/null | head -n 1 | tr -d ' \r')
    case "$_v" in
        false|FALSE|0|off|no) echo 0 ;;
        true|TRUE|1|on|yes)   echo 1 ;;
        *)                    echo "$3" ;;
    esac
}

# 等开机完成（最多 120 秒）
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 120 ]; do
    sleep 1
    i=$((i + 1))
done

# 再等 /storage/emulated/0 挂上来。开机早期它还没准备好，
# 这时候往里写会失败，后面所有脚本读写都会跟着出错。
i=0
while [ ! -d /storage/emulated/0/Android ] && [ $i -lt 90 ]; do
    sleep 1
    i=$((i + 1))
done

DATA="$NEW_DIR"
mkdir -p "$DATA/scripts" 2>/dev/null
if ! ( : > "$DATA/.wtest" ) 2>/dev/null; then
    # 极端情况：/storage 没挂上或无权限。为了不整机失效，退回 /data/adb，
    # 并且在启动输出里明确写出来，方便察觉。
    DATA="$OLD_DIR"
    mkdir -p "$DATA/scripts" 2>/dev/null
    FALLBACK=1
fi
rm -f "$DATA/.wtest" 2>/dev/null

# 再等一会，让输入设备和系统服务稳定
sleep 2

CFG="$DATA/config.conf"
if [ ! -f "$CFG" ]; then
    # 首次安装：把模块自带的默认配置拷过来
    cp "$MODDIR/config/sidekey.conf" "$CFG" 2>/dev/null
fi
[ -f "$CFG" ] || CFG="$MODDIR/config/sidekey.conf"

# 启动输出开关：log_daemon_out = false 时不生成 daemon.out（最省存储）
if [ "$(conf_bool "$CFG" log_daemon_out 1)" = "1" ]; then
    OUT="$DATA/daemon.out"
else
    OUT=/dev/null
fi

echo "==== $(date '+%F %T') service.sh 开始 ====" >> "$OUT"
[ "$FALLBACK" = "1" ] && echo "警告: $NEW_DIR 不可写，本次退回 $OLD_DIR" >> "$OUT"
echo "数据目录: $DATA" >> "$OUT"

BIN="$MODDIR/bin/sidekeyd"
[ -x "$BIN" ] || BIN="$DATA/bin/sidekeyd"

if [ ! -x "$BIN" ]; then
    echo "错误: 找不到可执行的 sidekeyd（$BIN）" >> "$OUT"
    exit 1
fi

# 干掉旧实例
pkill -f sidekeyd 2>/dev/null
sleep 1

# 上次异常退出可能把三段式节点留成了 0200（chmod 屏蔽方式），开机先扶正
for n in /proc/tristatekey/tri_state /sys/class/switch/tri-state-key/state; do
    [ -e "$n" ] && chmod 0644 "$n" 2>/dev/null
done

echo "启动: $BIN --config $CFG" >> "$OUT"
nohup "$BIN" --config "$CFG" >> "$OUT" 2>&1 &

sleep 1
if pgrep -f sidekeyd > /dev/null 2>&1; then
    echo "sidekeyd 已在运行" >> "$OUT"
else
    echo "警告: sidekeyd 没起来，看 $DATA/sidekeyd.log" >> "$OUT"
fi

#!/system/bin/sh
# Magisk / KernelSU 安装脚本

SKIPUNZIP=0

ui_print " "
ui_print "======== 侧键增强 SideKey Enhancer ========"
ui_print "- 设备: $(getprop ro.product.model)"
ui_print "- 系统: $(getprop ro.build.version.release)"
ui_print "=========================================="

if [ "$ARCH" != "arm64" ] && [ "$ARCH" != "arm" ]; then
    abort "! 只支持 arm64 / arm 架构（当前 $ARCH）"
fi

if [ ! -f "$MODPATH/bin/sidekeyd" ]; then
    abort "! 模块里没有 bin/sidekeyd，包是坏的，请重新下载"
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/bin/sidekeyd" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755

# 兜底：个别管理器没实现 set_perm（或 zip 里权限位丢了），这里再 chmod 一次，
# 否则会出现「文件在、但执行报 Permission denied」。
chmod 0755 "$MODPATH/bin/sidekeyd" 2>/dev/null
chmod 0755 "$MODPATH"/*.sh 2>/dev/null
chmod 0755 "$MODPATH"/scripts/*.sh 2>/dev/null

# 自检：装完立刻试着跑一下二进制，能跑说明架构 / 链接器 / 权限都对。
if [ -f "$MODPATH/bin/sidekeyd" ]; then
    if [ ! -x "$MODPATH/bin/sidekeyd" ]; then
        chmod 0755 "$MODPATH/bin/sidekeyd" 2>/dev/null
    fi
    SKV=$("$MODPATH/bin/sidekeyd" --version 2>&1)
    SKR=$?
    if [ "$SKR" -eq 0 ] && [ -n "$SKV" ]; then
        ui_print "- 二进制自检通过: $SKV"
    else
        ui_print "! 二进制无法运行（退出码 $SKR）：$SKV"
        ui_print "! 常见原因：机型不是 arm64，或刷入的包被解压坏了"
    fi
fi

# 数据目录放进用户可见的 Android 目录，用文件管理器就能改脚本/配置
# 注意：/storage/emulated/0 是 noexec，脚本一律用 sh 调用，不能直接执行
DATA=/storage/emulated/0/Android/sidekey
mkdir -p "$DATA/scripts" 2>/dev/null

if ( : > "$DATA/.wtest" ) 2>/dev/null; then
    rm -f "$DATA/.wtest"
else
    ui_print "! 无法写入 $DATA（存储没挂上？）"
    ui_print "! 配置和脚本会退回到 /data/adb/sidekey"
    DATA=/data/adb/sidekey
    mkdir -p "$DATA/scripts" 2>/dev/null
fi

# 配置文件只在首次安装时生成，升级不覆盖（保住你的自定义）
if [ ! -f "$DATA/config.conf" ]; then
    cp "$MODPATH/config/sidekey.conf" "$DATA/config.conf"
    chmod 0666 "$DATA/config.conf" 2>/dev/null
    ui_print "- 已生成配置: $DATA/config.conf"
else
    ui_print "- 已有配置，保留不动: $DATA/config.conf"
fi

# ── 三段式检测方式：装机时自动识别一次，直接写进配置，WebUI 不用再选 ──
# 先找 proc 节点（最准），没有再让 sidekeyd --probe 看有没有 KEY_MODE 按键上报
SL_BACKEND=auto
SL_NODE=""
for p in /proc/tristatekey/tri_state /proc/tri_state_key/tri_state /sys/class/switch/tri-state-key/state; do
    if [ -e "$p" ]; then
        SL_BACKEND=proc
        SL_NODE=$p
        break
    fi
done
if [ "$SL_BACKEND" = auto ] && "$MODPATH/bin/sidekeyd" -p 2>/dev/null | grep -q "KEY_MODE"; then
    SL_BACKEND=evdev
fi
if [ "$SL_BACKEND" = proc ]; then
    sed -i "s#^backend = .*#backend = proc#; s#^proc_path = .*#proc_path = $SL_NODE#" "$DATA/config.conf" 2>/dev/null
    ui_print "- 三段式检测: proc 节点（$SL_NODE）"
elif [ "$SL_BACKEND" = evdev ]; then
    sed -i "s#^backend = .*#backend = evdev#" "$DATA/config.conf" 2>/dev/null
    ui_print "- 三段式检测: evdev 按键上报"
else
    ui_print "- 三段式检测: 没探到固定方式，运行时自动试"
fi

# 我的脚本目录只放一个示例；内置动作留在模块里按名字调用，不往这里堆文件
if [ -z "$(ls -A "$DATA/scripts" 2>/dev/null)" ]; then
    cp "$MODPATH/scripts/示例.sh" "$DATA/scripts/示例.sh" 2>/dev/null
    chmod 0666 "$DATA/scripts/示例.sh" 2>/dev/null
fi
ui_print "- 脚本目录: $DATA/scripts（内置动作不占这里，直接选就行）"

# 清掉可能残留的旧实例锁（锁现在放 /dev，重启即清；这里兜底清一遍旧位置的）
rm -f /dev/sidekeyd.lock "$DATA/sidekeyd.lock" 2>/dev/null

ui_print "- 装完重启，或执行 $MODPATH/action.sh 立即启动"

if [ -f "$MODPATH/webroot/index.html" ]; then
    if [ -n "$KSU" ] || [ -n "$KSU_VER" ] || [ -d /data/adb/ksu ]; then
        ui_print "- WebUI: 重进管理器后，模块页会出现「打开 WebUI」"
    else
        ui_print "- WebUI 文件就绪（当前管理器可能没有 WebUI 入口，可手改 $DATA/config.conf）"
    fi
else
    ui_print "! 缺少 webroot/index.html，WebUI 不可用"
fi

ui_print " "

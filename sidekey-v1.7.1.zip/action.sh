#!/system/bin/sh
# Magisk / KernelSU 模块的"操作"按钮：改了配置后点它即可重启守护进程
MODDIR=${0%/*}
NEW_DIR=/storage/emulated/0/Android/sidekey
OLD_DIR=/data/adb/sidekey

DATA="$NEW_DIR"
if ! ( : > "$DATA/.wtest" ) 2>/dev/null; then
    DATA="$OLD_DIR"
fi
rm -f "$DATA/.wtest" 2>/dev/null
mkdir -p "$DATA/scripts" 2>/dev/null

BIN="$MODDIR/bin/sidekeyd"
[ -x "$BIN" ] || BIN="$DATA/bin/sidekeyd"
CFG="$DATA/config.conf"
[ -f "$CFG" ] || CFG="$MODDIR/config/sidekey.conf"

# 读配置项（读不到就用默认值）
conf_get() {    # $1=键名  $2=默认值
    _v=$(sed -n "s/^[[:space:]]*$1[[:space:]]*=[[:space:]]*//p" "$CFG" 2>/dev/null | head -n 1 | tr -d '\r')
    if [ -n "$_v" ]; then echo "$_v"; else echo "$2"; fi
}
conf_bool() {   # $1=键名  $2=默认值(0/1)
    case "$(conf_get "$1" "")" in
        false|FALSE|0|off|no) echo 0 ;;
        true|TRUE|1|on|yes)   echo 1 ;;
        *)                    echo "$2" ;;
    esac
}

LOG=$(conf_get log_file "$DATA/sidekeyd.log")

# 启动输出开关：关掉后不再往 daemon.out 里写
if [ "$(conf_bool log_daemon_out 1)" = "1" ]; then
    OUT="$DATA/daemon.out"
else
    OUT=/dev/null
fi

echo "重启 sidekeyd ..."
echo "配置: $CFG"
pkill -x sidekeyd 2>/dev/null
sleep 1
nohup "$BIN" --config "$CFG" >> "$OUT" 2>&1 &
sleep 1

if pgrep -f sidekeyd > /dev/null 2>&1; then
    echo "已启动"
    echo ""
    if [ "$(conf_bool log_enabled 1)" = "1" ]; then
        echo "--- 最近日志（$LOG） ---"
        tail -n 20 "$LOG" 2>/dev/null
    else
        echo "（日志总开关是关的：不会写任何日志，要排查请在「日志」页打开）"
    fi
else
    echo "启动失败，看 $OUT"
    tail -n 30 "$OUT" 2>/dev/null
fi

#!/system/bin/sh
# post-fs-data：开机极早期执行，此时 system_server 还没起来，/storage 也还没挂，
# 所以这里不能往数据目录写日志（写 /data/local/tmp）。
MODDIR=${0%/*}
LOG=/data/local/tmp/sidekey_postfs.log

# uinput 是"屏蔽原始功能"的前提。root 本身能写，但有些机型 SELinux 会拦，
# 需要时再配合模块根目录的 sepolicy.rule。
if [ -e /dev/uinput ]; then
    chmod 0666 /dev/uinput 2>/dev/null
    echo "$(date '+%F %T') uinput ok" >> "$LOG" 2>/dev/null
else
    echo "$(date '+%F %T') /dev/uinput 不存在，内核可能没开 CONFIG_INPUT_UINPUT" >> "$LOG" 2>/dev/null
fi

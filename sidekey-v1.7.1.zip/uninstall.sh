#!/system/bin/sh
# 卸载时停止守护进程（冻结的节点 / chmod 过的权限会在重启后自动恢复，
# 这里再主动扶正一次，避免卸载后滑块失灵）
pkill -f sidekeyd 2>/dev/null
sleep 1
for n in /proc/tristatekey/tri_state /sys/class/switch/tri-state-key/state; do
    [ -e "$n" ] && chmod 0644 "$n" 2>/dev/null
done
